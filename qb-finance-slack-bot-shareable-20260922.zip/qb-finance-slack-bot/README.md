# QuickBooks Financial Agent for Slack

Answers live financial questions ("what's our AR aging look like", "P&L for Q2",
"cash flow last 30 days") by calling the QuickBooks Online API directly — no vector
DB, no stale snapshots. Deployed on Supabase Edge Functions, wired to Slack's Events
API, powered by Claude tool-use.

This repo is **Option #3** (the real, reusable deliverable). See the bottom of this
file for **Option #1** (zero-code version using Anthropic's own QuickBooks connector +
Claude in Slack) — stand that one up first to see what people actually ask, then use
what you learn here to extend this repo.

## Architecture

```
Slack (app_mention/DM)
   -> Events API POST -> Supabase Edge Function (slack-events)
        -> verify Slack signature
        -> ACK Slack in <3s, keep working in background (EdgeRuntime.waitUntil)
        -> pull/refresh QuickBooks OAuth token from Supabase Postgres
        -> Claude tool-use loop (supabase/functions/_shared/claude.ts)
             -> calls QuickBooks Online API live (P&L, Balance Sheet, Cash Flow,
                AR Aging, Company Info, or a raw QBO query)
        -> post the answer back to the Slack channel/thread
        -> log the Q&A + which QB calls were made to query_log (your audit trail —
           mine this later to see what to build next)
```

Nothing about the business data is embedded or cached. The only thing you'd ever
cache is reference data that barely changes (chart of accounts, classes) — there's a
`getChartOfAccounts()` helper in `quickbooks.ts` ready for that if you add a scheduled
job later.

## One-time setup (recommended)

```bash
bash scripts/install.sh    # prompts for YOUR credentials → writes .env → optional deploy
```

Or see **[INSTALL.md](INSTALL.md)** for a full walkthrough. To package a clean zip for others (no secrets):

```bash
bash scripts/package-share.sh
```

## One-time setup (manual)

### 1. QuickBooks app (you said you already have this)
Confirm in [developer.intuit.com](https://developer.intuit.com) under your app's
**Keys & OAuth**: note `Client ID` and `Client Secret`. Also confirm your app has the
`com.intuit.quickbooks.accounting` scope and, if you're testing first, a sandbox
company available.

### 2. Get the first access/refresh token pair
QuickBooks uses OAuth 2.0 authorization-code flow — there's no way to mint the first
token without a human clicking "Authorize." Fastest path for a single-company internal
tool: use Intuit's **OAuth 2.0 Playground**
(developer.intuit.com -> your app -> "OAuth 2.0 Playground" in the left nav):
1. Select your app + the `com.intuit.quickbooks.accounting` scope.
2. Authorize against the company you want this bot reading from.
3. Copy the resulting `access_token`, `refresh_token`, and `realm_id` (Company ID).

(A proper `/connect` redirect-flow edge function is a natural v2 addition if you ever
need to onboard additional client companies — flag it if you want that added when we
productize this further.)

### 3. Seed the database
```sql
insert into qb_connections (realm_id, environment, access_token, access_token_expires_at,
  refresh_token, refresh_token_expires_at, company_name)
values (
  'YOUR_REALM_ID',
  'sandbox', -- or 'production'
  'PASTE_ACCESS_TOKEN',
  now() + interval '1 hour',       -- QBO access tokens last 1 hour
  'PASTE_REFRESH_TOKEN',
  now() + interval '100 days',     -- QBO refresh tokens last 100 days, rotate on use
  'Your Company Name'
);
```
Run `supabase db push` first to apply `supabase/migrations/0001_init.sql`, then run
the insert above via the Supabase SQL editor.

> The token refresh logic in `quickbooks.ts` runs automatically on every question and
> persists the rotated tokens — as long as *someone* asks a question at least once
> every ~90 days, this connection never needs to be re-authorized manually.

### 4. Slack app
Go to [api.slack.com/apps](https://api.slack.com/apps) -> **Create New App** -> **From
a manifest** -> paste `slack-app-manifest.json` (update the `request_url` after step 5,
you can come back and edit it). Install the app to your workspace, then grab:
- **Bot User OAuth Token** (`xoxb-...`) from OAuth & Permissions
- **Signing Secret** from Basic Information

### 5. Deploy
```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push

supabase secrets set \
  ANTHROPIC_API_KEY=sk-ant-... \
  ANTHROPIC_MODEL=claude-sonnet-4-5-20250929 \
  SLACK_BOT_TOKEN=xoxb-... \
  SLACK_SIGNING_SECRET=... \
  QB_CLIENT_ID=... \
  QB_CLIENT_SECRET=...

supabase functions deploy slack-events --no-verify-jwt
```
`--no-verify-jwt` is required — Slack's requests don't carry a Supabase auth JWT, we
verify authenticity via the Slack signing secret instead (see `_shared/slack.ts`).

Your function URL will look like:
`https://YOUR_PROJECT.functions.supabase.co/slack-events`

### 6. Wire up the Slack event subscription
Back in your Slack app -> **Event Subscriptions** -> turn on -> paste the function URL
as the Request URL. Slack will immediately POST a `url_verification` challenge — the
function handles that automatically, you should see it go green. Then add the bot to
whatever channel(s) should have access to financial data.

### 7. Test it
In Slack: `@qb-finance-bot what's our AR aging as of today?` or DM it directly.

## Extending this
- **New tools**: add a function to `quickbooks.ts`, add its schema to the `TOOLS`
  array and the `runTool()` switch in `claude.ts`. That's it — Claude picks it up.
- **Already covered tools** (beyond core reports): customer search/payments/invoices,
  vendor expenses & balances, unpaid invoices/bills, AP aging, P&L detail (expense
  categories), budget vs actual (if budgets exist in QBO), cash position snapshot for
  near-term outlooks.
- **Multi-company / multi-client**: this v1 assumes one QuickBooks company per
  deployment. To productize across your fractional CTO clients, key `qb_connections`
  by `slack_team_id` and look it up per-event in `getConnection()` instead of grabbing
  the single row.
- **Scheduled digests**: see [Scheduled reports](#scheduled-reports) below.
- **Permissions**: right now anyone in a channel the bot is in can ask anything. If
  you need to restrict who sees what (e.g. contractors shouldn't see payroll-adjacent
  numbers), add a Slack user-ID allowlist check in `slack-events/index.ts` before
  calling `handleQuestion`.

## Scheduled reports

Automated digests post to your Slack digest channel at **6 PM Pacific**:

| Report | When | Contents |
|--------|------|----------|
| **Daily** | Mon–Fri | Cash position + AR aging |
| **Weekly** | Friday | Prior Mon–Sun P&L + AR aging |
| **Monthly** | Last day of month | P&L + Balance Sheet + cash flow |

Setup (one time):

```bash
./scripts/setup-schedules.sh
```

This deploys `scheduled-digest`, applies the `pg_cron` hourly trigger, and stores a
`CRON_SECRET`. Add `CRON_SECRET` and `SLACK_DIGEST_CHANNEL` to `.env`.

Test immediately (does not wait for 6 PM):

```bash
source .env
curl -X POST "https://${SUPABASE_PROJECT_REF}.supabase.co/functions/v1/scheduled-digest?force=weekly" \
  -H "x-cron-secret: $CRON_SECRET"
```

After adding `channels:read` / `channels:join` scopes, **reinstall the Slack app** to
your workspace so scheduled posts can resolve and join your digest channel.

---

## Option #1 — zero-code version (do this first)

Before or alongside deploying the above, stand up the fast version to see real usage
patterns:

1. **Connect the QuickBooks connector**: in claude.ai admin settings, go to
   **Connectors** (or Settings -> Capabilities -> Connectors, depending on your org's
   layout) and connect **"Intuit QuickBooks"**. Authorize it against your company.
   Exposed tools: P&L generator, cash-flow generator, industry benchmarking, company
   info, transaction import, and a few more.
2. **Enable Claude in Slack (Claude Tag)**: run `/install-slack-app` from within
   Claude, or set it up via your Slack admin — this lets your team `@Claude` in any
   channel and it answers using whatever connectors are enabled for the org.
3. Turn it on for one internal channel first, not the whole workspace, until you've
   sanity-checked what it does with real questions.

**Do not enable the write-capable "Meridian" QuickBooks connector** (create bills,
expenses, customers, etc.) for this — that's a different risk profile (it can change
your books) and should be a deliberate, separate decision if you ever want it.

Whatever people actually ask in the Option #1 channel is your best signal for which
tools to prioritize adding to the Option #3 agent above.
