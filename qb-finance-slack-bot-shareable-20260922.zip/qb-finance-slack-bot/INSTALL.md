# Install guide (for people who received the shareable zip)

This bot answers live QuickBooks questions in Slack. Each installation is **fully separate**:
you create your own Supabase project, Slack app, Anthropic key, and QuickBooks app.
Nothing from the packager’s accounts is included.

## What you need

| Account | Why |
|---------|-----|
| [Supabase](https://supabase.com) project | Hosts the Edge Functions + Postgres |
| [Anthropic](https://platform.claude.com/settings/keys) API key | Claude answers questions |
| [Slack app](https://api.slack.com/apps) | Bot in your workspace |
| [Intuit QuickBooks](https://developer.intuit.com) app | Live company data (read-only) |

## Quick start

```bash
unzip qb-finance-slack-bot-shareable-*.zip
cd qb-finance-slack-bot

# Interactive wizard — prompts for YOUR credentials, writes a private .env
bash scripts/install.sh
```

The wizard can also deploy for you. Or deploy later:

```bash
export SUPABASE_ACCESS_TOKEN=...   # from supabase.com/dashboard/account/tokens
bash scripts/deploy-all.sh
```

## After install

### 1. Seed QuickBooks OAuth tokens

In Supabase → **SQL Editor**, run (replace placeholders):

```sql
insert into qb_connections (
  realm_id, environment, access_token, access_token_expires_at,
  refresh_token, refresh_token_expires_at, company_name
) values (
  'YOUR_REALM_ID',
  'production',  -- or 'sandbox'
  'PASTE_ACCESS_TOKEN',
  now() + interval '1 hour',
  'PASTE_REFRESH_TOKEN',
  now() + interval '100 days',
  'Your Company Name'
);
```

Get tokens from Intuit **OAuth 2.0 Playground** on *your* app (accounting scope).

### 2. Connect Slack Events

1. Create a Slack app → **From a manifest** → paste `slack-app-manifest.json`
2. Install to your workspace; copy Bot Token + Signing Secret into `.env` if you skipped the wizard
3. **Event Subscriptions** → Request URL:

```
https://YOUR_PROJECT_REF.supabase.co/functions/v1/slack-events
```

4. Invite the bot to a channel and ask: `@qb-finance-bot what's our cash position?`

### 3. Optional scheduled digests

```bash
bash scripts/setup-schedules.sh
```

## Privacy & isolation

- Your `.env` stays on your machine (file mode `600`). **Never email or zip it.**
- Deploy targets only `SUPABASE_PROJECT_REF` from *your* `.env`.
- The shareable zip excludes `.env`, deploy caches, and personal project IDs.
- Uninstalling / deleting *your* Supabase project does not affect anyone else.

## Security notes

- Deploy with `--no-verify-jwt` because Slack does not send a Supabase JWT; authenticity is checked with the Slack signing secret.
- Rotate any key you accidentally shared.
- Prefer Cash basis (`QB_ACCOUNTING_METHOD=Cash`) if you want reports to reflect money that actually moved.

## Troubleshooting

```bash
bash scripts/health-check.sh
```

Common issues: missing `CRON_SECRET`, expired QB refresh token (`invalid_grant` → re-authorize in OAuth Playground), Slack Socket Mode left ON (must be OFF for Events API).
