#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -f .env ]]; then
  echo "Missing .env file."
  exit 1
fi

# shellcheck disable=SC1091
source .env

if [[ -z "${ANTHROPIC_API_KEY:-}" || "$ANTHROPIC_API_KEY" == sk-ant-REPLACE_ME ]]; then
  echo "Set ANTHROPIC_API_KEY in .env first."
  echo "Create one at: https://platform.claude.com/settings/keys"
  exit 1
fi

MODEL="${ANTHROPIC_MODEL:-claude-sonnet-4-5-20250929}"

echo "Testing Anthropic API key (model: $MODEL)..."

RESPONSE="$(curl -sS -w "\n%{http_code}" https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d "{\"model\":\"$MODEL\",\"max_tokens\":50,\"messages\":[{\"role\":\"user\",\"content\":\"Say hello in five words or fewer.\"}]}")"

BODY="$(echo "$RESPONSE" | sed '$d')"
STATUS="$(echo "$RESPONSE" | tail -n 1)"

if [[ "$STATUS" == "200" ]]; then
  echo "OK — Anthropic API key is valid."
  echo "$BODY" | head -c 500
  echo ""
  exit 0
fi

echo "Failed (HTTP $STATUS):"
echo "$BODY"
exit 1
