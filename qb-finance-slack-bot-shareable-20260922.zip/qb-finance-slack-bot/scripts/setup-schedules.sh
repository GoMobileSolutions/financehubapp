#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -f .env ]]; then
  echo "Missing .env — run: bash scripts/install.sh"
  exit 1
fi

set -a
source .env
set +a

PROJECT_REF="${SUPABASE_PROJECT_REF:-}"
if [[ -z "$PROJECT_REF" && "${SUPABASE_URL:-}" =~ https://([a-z0-9]+)\.supabase\.co ]]; then
  PROJECT_REF="${BASH_REMATCH[1]}"
fi
if [[ -z "$PROJECT_REF" ]]; then
  echo "Set SUPABASE_PROJECT_REF in .env"
  exit 1
fi

if [[ -z "${CRON_SECRET:-}" ]]; then
  CRON_SECRET="$(openssl rand -hex 32)"
  echo "Generated CRON_SECRET — add this line to .env:"
  echo "CRON_SECRET=$CRON_SECRET"
fi

echo "==> Setting Supabase secrets (project $PROJECT_REF)..."
npx supabase secrets set \
  "CRON_SECRET=$CRON_SECRET" \
  "SLACK_DIGEST_CHANNEL=${SLACK_DIGEST_CHANNEL:-finance-bot}" \
  "SLACK_COLLECTIONS_CHANNEL=${SLACK_COLLECTIONS_CHANNEL:-}" \
  --project-ref "$PROJECT_REF"

echo "==> Applying digest migration..."
npx supabase db push --yes || npx supabase db push

echo "==> Storing cron secret and function URLs for pg_cron..."
npx supabase db query --linked <<SQL
insert into app_config (key, value, updated_at) values
  ('cron_secret', '${CRON_SECRET}', now()),
  ('scheduled_digest_url', 'https://${PROJECT_REF}.supabase.co/functions/v1/scheduled-digest', now()),
  ('collections_digest_url', 'https://${PROJECT_REF}.supabase.co/functions/v1/collections-digest', now())
on conflict (key) do update set value = excluded.value, updated_at = now();
SQL

echo "==> Deploying digest functions..."
npx supabase functions deploy scheduled-digest --no-verify-jwt --project-ref "$PROJECT_REF"
npx supabase functions deploy collections-digest --no-verify-jwt --project-ref "$PROJECT_REF" || true
npx supabase functions deploy slack-events --no-verify-jwt --project-ref "$PROJECT_REF"

echo ""
echo "Schedules (6 PM Pacific):"
echo "  - Daily (Mon–Fri): cash + AR aging"
echo "  - Weekly (Fri): prior Mon–Sun P&L + AR aging"
echo "  - Monthly (last day of month): P&L + Balance Sheet + cash flow"
echo "  - Collections (Friday): AR aging detail"
echo "  - Posts to #${SLACK_DIGEST_CHANNEL:-finance-bot}"
echo ""
echo "Test weekly digest:"
echo "  curl -X POST 'https://${PROJECT_REF}.supabase.co/functions/v1/scheduled-digest?force=weekly' \\"
echo "    -H 'x-cron-secret: \$CRON_SECRET'"
