#!/usr/bin/env bash
# Push secrets + deploy edge functions to the project in .env (YOUR project only).
# Docker is NOT required for remote deploys.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -f .env ]]; then
  echo "Missing .env — run: bash scripts/install.sh"
  exit 1
fi

# shellcheck disable=SC1091
set -a
source .env
set +a

PROJECT_REF="${SUPABASE_PROJECT_REF:-}"
if [[ -z "$PROJECT_REF" ]]; then
  # Derive from SUPABASE_URL if present: https://xxxx.supabase.co
  if [[ "${SUPABASE_URL:-}" =~ https://([a-z0-9]+)\.supabase\.co ]]; then
    PROJECT_REF="${BASH_REMATCH[1]}"
  fi
fi
if [[ -z "$PROJECT_REF" || "$PROJECT_REF" == "YOUR_PROJECT_REF" ]]; then
  echo "Set SUPABASE_PROJECT_REF in .env (Supabase → Settings → General → Reference ID)."
  exit 1
fi

if [[ -z "${SUPABASE_ACCESS_TOKEN:-}" ]]; then
  echo "Tip: export SUPABASE_ACCESS_TOKEN from https://supabase.com/dashboard/account/tokens"
  echo "     (avoids macOS Keychain prompts)"
fi

echo "==> Using Supabase project: $PROJECT_REF"
echo "==> Setting edge function secrets..."
npx supabase secrets set --project-ref "$PROJECT_REF" \
  "ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY" \
  "ANTHROPIC_MODEL=${ANTHROPIC_MODEL:-claude-sonnet-4-5-20250929}" \
  "SLACK_BOT_TOKEN=$SLACK_BOT_TOKEN" \
  "SLACK_SIGNING_SECRET=$SLACK_SIGNING_SECRET" \
  "QB_CLIENT_ID=$QB_CLIENT_ID" \
  "QB_CLIENT_SECRET=$QB_CLIENT_SECRET" \
  "QB_ACCOUNTING_METHOD=${QB_ACCOUNTING_METHOD:-Cash}" \
  "CRON_SECRET=$CRON_SECRET" \
  "SLACK_DIGEST_CHANNEL=${SLACK_DIGEST_CHANNEL:-finance-bot}" \
  "SLACK_COLLECTIONS_CHANNEL=${SLACK_COLLECTIONS_CHANNEL:-}"

echo "==> Linking project (for db push)..."
npx supabase link --project-ref "$PROJECT_REF" || true

echo "==> Pushing database migrations..."
npx supabase db push --yes || npx supabase db push

echo "==> Deploying slack-events..."
npx supabase functions deploy slack-events --no-verify-jwt --project-ref "$PROJECT_REF"

echo "==> Deploying scheduled-digest..."
npx supabase functions deploy scheduled-digest --no-verify-jwt --project-ref "$PROJECT_REF"

if [[ -d supabase/functions/collections-digest ]]; then
  echo "==> Deploying collections-digest..."
  npx supabase functions deploy collections-digest --no-verify-jwt --project-ref "$PROJECT_REF"
fi

if [[ -d supabase/functions/expense-qa-check ]]; then
  echo "==> Deploying expense-qa-check..."
  npx supabase functions deploy expense-qa-check --no-verify-jwt --project-ref "$PROJECT_REF" || true
fi

echo ""
echo "Done. Functions:"
echo "  https://${PROJECT_REF}.supabase.co/functions/v1/slack-events"
echo "  https://${PROJECT_REF}.supabase.co/functions/v1/scheduled-digest"
echo ""
echo "Wire Slack Event Subscriptions to the slack-events URL above."
echo "Optional: bash scripts/setup-schedules.sh"
echo "Optional: bash scripts/health-check.sh"
