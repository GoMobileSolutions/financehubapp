#!/usr/bin/env bash
# Deprecated entrypoint — use scripts/install.sh then scripts/deploy-all.sh
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo "Use: bash scripts/install.sh"
echo "Then: bash scripts/deploy-all.sh"
if [[ -f "$ROOT/.env" ]]; then
  bash "$ROOT/scripts/deploy-all.sh"
else
  bash "$ROOT/scripts/install.sh"
fi
