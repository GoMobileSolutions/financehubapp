#!/usr/bin/env bash
# Quick smoke test: Anthropic key, QB token refresh, Slack post, recent query_log errors.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -f .env ]]; then
  echo "Missing .env — copy from .env.example"
  exit 1
fi

# shellcheck disable=SC1091
source .env

echo "==> 1/4 Anthropic API"
bash "$ROOT/scripts/verify-anthropic-key.sh"

echo ""
echo "==> 2/4 QuickBooks token refresh"
CONN_JSON="$(curl -sS "${SUPABASE_URL}/rest/v1/qb_connections?select=refresh_token,realm_id,access_token_expires_at,refresh_token_expires_at&limit=1" \
  -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
  -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}")"
REFRESH="$(echo "$CONN_JSON" | python3 -c "import json,sys; print(json.load(sys.stdin)[0]['refresh_token'])")"
EXPIRES="$(echo "$CONN_JSON" | python3 -c "import json,sys; r=json.load(sys.stdin)[0]; print('access expires:', r['access_token_expires_at'], '| refresh expires:', r['refresh_token_expires_at'])")"
echo "$EXPIRES"

QB_RESP="$(curl -sS -w "\n%{http_code}" -X POST "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "Accept: application/json" \
  -u "${QB_CLIENT_ID}:${QB_CLIENT_SECRET}" \
  -d "grant_type=refresh_token&refresh_token=${REFRESH}")"
QB_BODY="$(echo "$QB_RESP" | sed '$d')"
QB_STATUS="$(echo "$QB_RESP" | tail -n 1)"
if [[ "$QB_STATUS" != "200" ]]; then
  echo "QB refresh FAILED (HTTP $QB_STATUS): $QB_BODY"
  echo "Re-authorize in Intuit OAuth Playground and update qb_connections."
  exit 1
fi
echo "QB refresh OK"

echo ""
echo "==> 3/4 Slack post to ${SLACK_DIGEST_CHANNEL:-bbfinances-bot}"
SLACK_RESP="$(curl -sS -X POST "https://slack.com/api/chat.postMessage" \
  -H "Authorization: Bearer ${SLACK_BOT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{\"channel\":\"${SLACK_DIGEST_CHANNEL}\",\"text\":\"bB Finances health check — $(date -u +%Y-%m-%dT%H:%MZ)\"}")"
if echo "$SLACK_RESP" | python3 -c "import json,sys; sys.exit(0 if json.load(sys.stdin).get('ok') else 1)"; then
  echo "Slack post OK"
else
  echo "Slack post FAILED: $SLACK_RESP"
  exit 1
fi

echo ""
echo "==> 4/4 Recent query_log errors"
curl -sS "${SUPABASE_URL}/rest/v1/query_log?select=created_at,question,error&error=not.is.null&order=created_at.desc&limit=3" \
  -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
  -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}" | python3 -m json.tool

echo ""
echo "All checks passed. Deploy latest functions if you changed code:"
echo "  bash scripts/deploy-all.sh"
