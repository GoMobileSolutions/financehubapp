#!/usr/bin/env bash
# Build a shareable zip with NO secrets, NO personal project IDs, NO deploy artifacts.
# Your .env is never included. Recipients run scripts/install.sh with their own keys.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PARENT="$(dirname "$ROOT")"
STAMP="$(date +%Y%m%d)"
OUT_NAME="qb-finance-slack-bot-shareable-${STAMP}.zip"
OUT_PATH="${PARENT}/${OUT_NAME}"
STAGE="${TMPDIR:-/tmp}/qb-finance-share-$$"

cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

mkdir -p "$STAGE/qb-finance-slack-bot"

# Copy only safe source paths
rsync -a \
  --exclude '.env' \
  --exclude '.env.bak*' \
  --exclude '.env.local' \
  --exclude '.git' \
  --exclude 'node_modules' \
  --exclude '.deploy*' \
  --exclude '.mcp-args*' \
  --exclude '.deploy-stage' \
  --exclude 'supabase/.temp' \
  --exclude '*.zip' \
  --exclude '.DS_Store' \
  --exclude '*.bak*' \
  "$ROOT/" "$STAGE/qb-finance-slack-bot/"

# Ensure template env is present (never the real .env)
if [[ ! -f "$STAGE/qb-finance-slack-bot/.env.example" ]]; then
  echo "ERROR: .env.example missing from package stage"
  exit 1
fi
# Never ship a real .env
rm -f "$STAGE/qb-finance-slack-bot/.env"

# Scan for accidental real secrets / personal project refs (exclude this packager script)
SCAN_HITS="$(grep -RInE \
  'sk-ant-api|xoxb-[0-9]|eyJhbGciOi|sbp_|ynszhcqmjpacdirsofio|9130355711444806|C0BSBTV1WDU' \
  "$STAGE/qb-finance-slack-bot" \
  --exclude='*.md' \
  --exclude='package-share.sh' \
  2>/dev/null | grep -v '.env.example' || true)"
if [[ -n "$SCAN_HITS" ]]; then
  echo "$SCAN_HITS" | head -20
  echo ""
  echo "ERROR: Possible personal data or secrets found in package. Aborting zip."
  exit 1
fi

# Soft warn on project refs only in docs (ok if placeholders)
echo "==> Creating $OUT_PATH"
rm -f "$OUT_PATH"
(
  cd "$STAGE"
  zip -r -q "$OUT_PATH" qb-finance-slack-bot \
    -x '*.DS_Store'
)

echo ""
echo "Shareable package ready:"
echo "  $OUT_PATH"
echo ""
ls -lh "$OUT_PATH"
echo ""
echo "Safe to share. Recipients should:"
echo "  1. Unzip"
echo "  2. Read INSTALL.md"
echo "  3. Run: bash scripts/install.sh"
echo ""
echo "Your live .env and Supabase project were NOT included."
