// Scheduled finance digests → QuickBooks → Claude → Slack channel.
// Triggered hourly by Supabase cron; runs digests only at 6 PM Pacific on the right days.

import { answerFinancialQuestion } from "../_shared/claude.ts";
import {
  digestQuestion,
  digestTitle,
  digestsDueAt6pmPT,
  getPTDateTime,
  type DigestType,
} from "../_shared/digest.ts";
import { createServiceClient, getConnection } from "../_shared/qb-connection.ts";
import { postMessage, resolveChannelId, deliverAnswer } from "../_shared/slack.ts";

const CRON_SECRET = Deno.env.get("CRON_SECRET");
const DIGEST_CHANNEL = Deno.env.get("SLACK_DIGEST_CHANNEL") ?? "bbfinances-bot";

function authorize(req: Request): boolean {
  if (!CRON_SECRET) return false;
  const header = req.headers.get("x-cron-secret") ?? req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  return header === CRON_SECRET;
}

async function claimRun(supabase: ReturnType<typeof createServiceClient>, type: DigestType, runDate: string) {
  const { error } = await supabase.from("digest_runs").insert({ digest_type: type, run_date: runDate });
  if (error?.code === "23505") return false; // already ran today
  if (error) throw new Error(`digest_runs insert failed: ${error.message}`);
  return true;
}

async function runDigest(
  supabase: ReturnType<typeof createServiceClient>,
  channelId: string,
  type: DigestType,
  ptDate: string,
) {
  const pt = getPTDateTime();
  const conn = await getConnection(supabase);
  const title = digestTitle(type, pt);
  const question = digestQuestion(type, pt);
  const startedAt = Date.now();

  const ack = await postMessage(channelId, `:chart_with_upwards_trend: ${title}\nLooking that up in QuickBooks...`);

  try {
    const { answer, toolCalls } = await answerFinancialQuestion(question, conn);
    await deliverAnswer(channelId, answer, undefined, ack.ts);

    await supabase.from("query_log").insert({
      slack_channel_id: channelId,
      question: `[scheduled:${type}] ${question}`,
      qb_tool_calls: toolCalls,
      answer,
      latency_ms: Date.now() - startedAt,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    await postMessage(channelId, `:x: Scheduled ${type} digest failed: \`${message}\``);
    await supabase.from("query_log").insert({
      slack_channel_id: channelId,
      question: `[scheduled:${type}] ${question}`,
      error: message,
      latency_ms: Date.now() - startedAt,
    });
    throw err;
  }
}

Deno.serve(async (req: Request) => {
  try {
    if (!authorize(req)) {
      return new Response("unauthorized", { status: 401 });
    }

    if (req.method !== "POST" && req.method !== "GET") {
      return new Response("method not allowed", { status: 405 });
    }

    const url = new URL(req.url);
    const forceType = url.searchParams.get("force") as DigestType | null;
    const pt = getPTDateTime();
    const due = forceType ? [forceType] : digestsDueAt6pmPT(pt);

    if (due.length === 0) {
      return Response.json({
        ok: true,
        skipped: true,
        reason: `No digests due at ${pt.date} ${pt.hour}:00 PT (weekday=${pt.weekday})`,
      });
    }

    const supabase = createServiceClient();

    // Prefer a channel ID (C...) so we don't need conversations.list scopes.
    // Falls back to name lookup, then last channel used in query_log.
    let channelId: string;
    if (/^C[A-Z0-9]+$/i.test(DIGEST_CHANNEL)) {
      channelId = DIGEST_CHANNEL;
    } else {
      try {
        channelId = await resolveChannelId(DIGEST_CHANNEL);
      } catch (lookupErr) {
        const { data } = await supabase
          .from("query_log")
          .select("slack_channel_id")
          .not("slack_channel_id", "is", null)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (data?.slack_channel_id) {
          channelId = data.slack_channel_id as string;
          console.warn(
            `Channel name lookup failed (${lookupErr}); using last query_log channel ${channelId}`,
          );
        } else {
          throw lookupErr;
        }
      }
    }

    const results: Array<{ type: DigestType; status: string }> = [];

    for (const type of due) {
      const claimed = forceType ? true : await claimRun(supabase, type, pt.date);
      if (!claimed) {
        results.push({ type, status: "already_ran" });
        continue;
      }

      try {
        await runDigest(supabase, channelId, type, pt.date);
        results.push({ type, status: "ok" });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        results.push({ type, status: `error: ${message}` });
      }
    }

    return Response.json({ ok: true, pt, channelId, results });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("scheduled-digest failed:", message);
    return Response.json({ ok: false, error: message }, { status: 500 });
  }
});
