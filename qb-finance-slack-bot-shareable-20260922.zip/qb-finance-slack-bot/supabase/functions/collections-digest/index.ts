// Weekly collections / AR digest → QuickBooks → Slack.
// Triggered hourly by Supabase cron; runs only at Friday 6 PM Pacific (or ?force=1).
// Historical backfill: ?force=1&compare_days=14 reconstructs AR from 14 days ago via QB report.

import {
  buildCollectionsDigest,
  buildHistoricalCollectionsCompare,
  formatCollectionsDigestSlack,
  isCollectionsDigestDue,
} from "../_shared/collections.ts";
import { getPTDateTime } from "../_shared/digest.ts";
import { createServiceClient, getConnection } from "../_shared/qb-connection.ts";
import { postMessage, resolveChannelId, deliverAnswer } from "../_shared/slack.ts";

const CRON_SECRET = Deno.env.get("CRON_SECRET");
const COLLECTIONS_CHANNEL =
  Deno.env.get("SLACK_COLLECTIONS_CHANNEL") ??
  Deno.env.get("SLACK_DIGEST_CHANNEL") ??
  "";

function authorize(req: Request): boolean {
  if (!CRON_SECRET) return false;
  const header =
    req.headers.get("x-cron-secret") ??
    req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  return header === CRON_SECRET;
}

async function claimRun(
  supabase: ReturnType<typeof createServiceClient>,
  runDate: string,
): Promise<boolean> {
  const { error } = await supabase
    .from("digest_runs")
    .insert({ digest_type: "collections", run_date: runDate });
  if (error?.code === "23505") return false;
  if (error) throw new Error(`digest_runs insert failed: ${error.message}`);
  return true;
}

async function resolveChannel(
  supabase: ReturnType<typeof createServiceClient>,
): Promise<string> {
  if (/^C[A-Z0-9]+$/i.test(COLLECTIONS_CHANNEL)) {
    return COLLECTIONS_CHANNEL;
  }
  try {
    return await resolveChannelId(COLLECTIONS_CHANNEL);
  } catch (lookupErr) {
    const { data } = await supabase
      .from("query_log")
      .select("slack_channel_id")
      .not("slack_channel_id", "is", null)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (data?.slack_channel_id) {
      console.warn(
        `Channel name lookup failed (${lookupErr}); using last query_log channel ${data.slack_channel_id}`,
      );
      return data.slack_channel_id as string;
    }
    throw lookupErr;
  }
}

Deno.serve(async (req: Request) => {
  try {
    if (!authorize(req)) {
      return new Response("unauthorized", { status: 401 });
    }

    if (req.method !== "POST" && req.method !== "GET") {
      return new Response("method not allowed", { status: 405 });
    }

    const url = new URL(req.url);
    const force = url.searchParams.get("force") === "1" ||
      url.searchParams.get("force") === "true" ||
      url.searchParams.get("force") === "collections";
    const compareDaysRaw = url.searchParams.get("compare_days");
    const compareDays = compareDaysRaw ? Math.min(90, Math.max(1, parseInt(compareDaysRaw, 10))) : 0;

    const pt = getPTDateTime();
    if (!force && !compareDays && !isCollectionsDigestDue(pt)) {
      return Response.json({
        ok: true,
        skipped: true,
        reason: `Collections digest not due at ${pt.date} ${pt.hour}:00 PT (weekday=${pt.weekday}); due Fri 18:00 PT`,
      });
    }

    const supabase = createServiceClient();
    // Historical compares never claim the weekly slot.
    const claimed = force || compareDays > 0 ? true : await claimRun(supabase, pt.date);
    if (!claimed) {
      return Response.json({ ok: true, skipped: true, reason: "already_ran", pt });
    }

    const channelId = await resolveChannel(supabase);
    const conn = await getConnection(supabase);
    const startedAt = Date.now();

    const modeLabel = compareDays > 0
      ? `Historical ${compareDays}-day AR compare`
      : "Collections Report";

    const ack = await postMessage(
      channelId,
      `Hey <!channel>\nPulling your ${modeLabel} from QuickBooks...`,
    );

    try {
      const payload = compareDays > 0
        ? await buildHistoricalCollectionsCompare(conn, compareDays, pt.date)
        : await buildCollectionsDigest(supabase, conn, pt.date);

      const text = formatCollectionsDigestSlack(payload);
      await deliverAnswer(channelId, text, undefined, ack.ts);

      await supabase.from("query_log").insert({
        slack_channel_id: channelId,
        question: compareDays > 0
          ? `[collections:compare_days=${compareDays}] AR compare ${pt.date}`
          : `[scheduled:collections] AR digest ${pt.date}`,
        qb_tool_calls: [
          {
            tool: compareDays > 0 ? "historical_ar_compare" : "get_ar_aging_detail",
            input: { as_of_date: pt.date, compare_days: compareDays || undefined },
            result_summary:
              `${payload.current.invoices.length} open now; ` +
              `recovered ${payload.diff.total_recovered}; ` +
              `new ${payload.diff.new_outstanding_count}; ` +
              `prev ${payload.diff.previous_snapshot_date}`,
          },
        ],
        answer: text,
        latency_ms: Date.now() - startedAt,
      });

      return Response.json({
        ok: true,
        pt,
        channelId,
        mode: compareDays > 0 ? "historical_compare" : "digest",
        compare_days: compareDays || null,
        as_of_date: payload.as_of_date,
        previous_snapshot_date: payload.diff.previous_snapshot_date,
        total_outstanding: payload.current.total_outstanding,
        previous_total: payload.previous_total,
        invoice_count: payload.current.invoices.length,
        new_open_invoices: payload.diff.new_outstanding_count,
        new_outstanding_revenue: payload.diff.new_outstanding_revenue,
        invoices_recovered: payload.diff.payments_recovered_count,
        revenue_recovered: payload.diff.total_recovered,
        cash_collected: payload.week_payments?.total_collected ?? null,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      await postMessage(channelId, `:x: Collections digest failed: \`${message}\``);
      await supabase.from("query_log").insert({
        slack_channel_id: channelId,
        question: compareDays > 0
          ? `[collections:compare_days=${compareDays}] AR compare ${pt.date}`
          : `[scheduled:collections] AR digest ${pt.date}`,
        error: message,
        latency_ms: Date.now() - startedAt,
      });
      throw err;
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("collections-digest failed:", message);
    return Response.json({ ok: false, error: message }, { status: 500 });
  }
});
