// lib/qbClient.ts
// QuickBooks API query helper for the expense-coding QA agent.
//
// ⚠️ ADAPT THIS: getAccessToken() below is a stub. Replace it with whatever
// token retrieval/refresh logic `scheduled-digest` already uses in this same
// Supabase project — you've already solved QB OAuth once, reuse it here
// instead of re-implementing it.

// lib/qbClient.ts
import { createServiceClient, getConnection } from "../../_shared/qb-connection.ts";

const QB_API_BASE = "https://quickbooks.api.intuit.com/v3/company";

export interface QBCredentials {
  accessToken: string;
  realmId: string;
}

export async function getAccessToken(): Promise<QBCredentials> {
  const supabase = createServiceClient();
  const conn = await getConnection(supabase);

  // The exact field name for realm ID on your qb_connections row may differ
  // (realm_id / realmId / company_id) — this tries the common ones and falls
  // back to the QB_REALM_ID secret you already set. If none hit, the error
  // below tells you exactly what's missing.
  const realmId =
    (conn as any).realm_id ??
    (conn as any).realmId ??
    (conn as any).company_id ??
    Deno.env.get("QB_REALM_ID");

  if (!realmId) {
    throw new Error(
      "Could not determine QB realm ID — check the field name on your qb_connections row",
    );
  }

  return { accessToken: conn.access_token, realmId };
}

export interface PurchaseLine {
  amount: number;
  accountName: string | null;
}

export interface PurchaseTxn {
  id: string;
  vendorName: string;
  txnDate: string;
  totalAmount: number;
  memo: string | null;
  lines: PurchaseLine[];
}

/**
 * Query QuickBooks Purchase transactions within a date range.
 * Handles pagination (QBO caps results per query; we page with STARTPOSITION).
 */
export async function queryPurchases(
  creds: QBCredentials,
  sinceDate: string, // 'YYYY-MM-DD'
): Promise<PurchaseTxn[]> {
  const results: PurchaseTxn[] = [];
  let startPosition = 1;
  const pageSize = 200;

  while (true) {
    const query = encodeURIComponent(
      `SELECT * FROM Purchase WHERE TxnDate >= '${sinceDate}' ORDERBY TxnDate STARTPOSITION ${startPosition} MAXRESULTS ${pageSize}`,
    );
    const url = `${QB_API_BASE}/${creds.realmId}/query?query=${query}`;

    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${creds.accessToken}`,
        Accept: "application/json",
      },
    });

    if (!res.ok) {
      const body = await res.text();
      throw new Error(`QuickBooks API error ${res.status}: ${body}`);
    }

    const data = await res.json();
    const purchases = data.QueryResponse?.Purchase ?? [];

    for (const p of purchases) {
      const lines: PurchaseLine[] = (p.Line ?? [])
        .filter((l: any) => l.DetailType === "AccountBasedExpenseLineDetail")
        .map((l: any) => ({
          amount: l.Amount ?? 0,
          accountName:
            l.AccountBasedExpenseLineDetail?.AccountRef?.name ?? null,
        }));

      results.push({
        id: p.Id,
        vendorName: p.EntityRef?.name ?? "Unknown Vendor",
        txnDate: p.TxnDate,
        totalAmount: p.TotalAmt ?? 0,
        memo: p.PrivateNote ?? null,
        lines,
      });
    }

    if (purchases.length < pageSize) break;
    startPosition += pageSize;
  }

  return results;
}
