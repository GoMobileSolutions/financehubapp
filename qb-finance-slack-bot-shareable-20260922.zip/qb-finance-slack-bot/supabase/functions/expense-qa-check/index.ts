// supabase/functions/expense-qa-check/index.ts
//
// Expense Coding QA Agent
// Flags recent QuickBooks expense transactions whose category doesn't match
// the vendor's historical coding pattern. Posts flagged items to Slack.
//
// Deploy: supabase functions deploy expense-qa-check --project-ref <ref>
// Schedule: same as scheduled-digest (daily, or a few days before month-end close)

import { getAccessToken, queryPurchases, PurchaseTxn } from "./lib/qbClient.ts";

const RECENT_WINDOW_DAYS = Number(Deno.env.get("RECENT_WINDOW_DAYS") ?? "7");
const BASELINE_WINDOW_DAYS = Number(
  Deno.env.get("BASELINE_WINDOW_DAYS") ?? "365",
);
const CONFIDENCE_THRESHOLD = Number(
  Deno.env.get("CONFIDENCE_THRESHOLD") ?? "0.7",
);
const MIN_HISTORY_FOR_BASELINE = Number(
  Deno.env.get("MIN_HISTORY_FOR_BASELINE") ?? "3",
);
const SLACK_WEBHOOK_URL = Deno.env.get("SLACK_WEBHOOK_URL");

function daysAgoISODate(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10);
}

interface VendorBaseline {
  // accountName -> count
  counts: Map<string, number>;
  total: number;
}

function buildBaseline(
  txns: PurchaseTxn[],
  cutoffDate: string,
): Map<string, VendorBaseline> {
  const baseline = new Map<string, VendorBaseline>();

  for (const txn of txns) {
    // Only use transactions OLDER than the recent window to build the baseline,
    // so a vendor isn't compared against itself within the same QA pass.
    if (txn.txnDate >= cutoffDate) continue;

    for (const line of txn.lines) {
      if (!line.accountName) continue;
      const existing = baseline.get(txn.vendorName) ?? {
        counts: new Map<string, number>(),
        total: 0,
      };
      existing.counts.set(
        line.accountName,
        (existing.counts.get(line.accountName) ?? 0) + 1,
      );
      existing.total += 1;
      baseline.set(txn.vendorName, existing);
    }
  }

  return baseline;
}

interface Flag {
  vendorName: string;
  amount: number;
  date: string;
  assignedCategory: string;
  suggestedCategory: string | null;
  confidence: number | null;
  reason: "miscode_suspected" | "new_vendor";
}

function evaluateRecent(
  recentTxns: PurchaseTxn[],
  cutoffDate: string,
  baseline: Map<string, VendorBaseline>,
): Flag[] {
  const flags: Flag[] = [];

  for (const txn of recentTxns) {
    if (txn.txnDate < cutoffDate) continue; // only evaluate the recent window

    const vendorBaseline = baseline.get(txn.vendorName);

    for (const line of txn.lines) {
      if (!line.accountName) continue;

      if (!vendorBaseline || vendorBaseline.total < MIN_HISTORY_FOR_BASELINE) {
        flags.push({
          vendorName: txn.vendorName,
          amount: line.amount,
          date: txn.txnDate,
          assignedCategory: line.accountName,
          suggestedCategory: null,
          confidence: null,
          reason: "new_vendor",
        });
        continue;
      }

      const matchCount = vendorBaseline.counts.get(line.accountName) ?? 0;
      const confidence = matchCount / vendorBaseline.total;

      if (confidence < CONFIDENCE_THRESHOLD) {
        // Find the dominant (most common) category for this vendor
        let topCategory = "";
        let topCount = 0;
        for (const [cat, count] of vendorBaseline.counts.entries()) {
          if (count > topCount) {
            topCount = count;
            topCategory = cat;
          }
        }

        flags.push({
          vendorName: txn.vendorName,
          amount: line.amount,
          date: txn.txnDate,
          assignedCategory: line.accountName,
          suggestedCategory: topCategory !== line.accountName ? topCategory : null,
          confidence,
          reason: "miscode_suspected",
        });
      }
    }
  }

  return flags;
}

function formatSlackMessage(flags: Flag[]): string {
  if (flags.length === 0) {
    return "✅ Expense Coding QA — no issues found in this run.";
  }

  let msg = `🚩 Expense Coding QA — ${flags.length} item(s) need a look\n\n`;

  flags.forEach((f, i) => {
    msg += `${i + 1}. Vendor: ${f.vendorName} | $${f.amount.toFixed(2)} | ${f.date}\n`;
    msg += `   Coded to: ${f.assignedCategory}\n`;
    if (f.reason === "new_vendor") {
      msg += `   ⚠️ New vendor — no coding history yet. Confirm this is right before it sets the pattern for future transactions.\n\n`;
    } else {
      const pct = f.confidence !== null ? Math.round(f.confidence * 100) : 0;
      msg += `   Usually coded to: ${f.suggestedCategory ?? "(mixed, no dominant category)"}\n`;
      msg += `   Confidence in current coding: ${pct}%\n\n`;
    }
  });

  return msg;
}

async function postToSlack(message: string): Promise<void> {
  if (!SLACK_WEBHOOK_URL) {
    console.warn("SLACK_WEBHOOK_URL not set — skipping Slack post. Message:");
    console.log(message);
    return;
  }
  const res = await fetch(SLACK_WEBHOOK_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text: message }),
  });
  if (!res.ok) {
    throw new Error(`Slack webhook failed: ${res.status} ${await res.text()}`);
  }
}

Deno.serve(async (_req: Request) => {
  try {
    const creds = await getAccessToken();

    const baselineSince = daysAgoISODate(BASELINE_WINDOW_DAYS);
    const recentCutoff = daysAgoISODate(RECENT_WINDOW_DAYS);

    // Pull the full window once (baseline period + recent period together),
    // then split by date — one QB query instead of two overlapping ones.
    const allTxns = await queryPurchases(creds, baselineSince);

    const baseline = buildBaseline(allTxns, recentCutoff);
    const flags = evaluateRecent(allTxns, recentCutoff, baseline);

    const message = formatSlackMessage(flags);
    await postToSlack(message);

    return new Response(
      JSON.stringify({
        ok: true,
        transactionsScanned: allTxns.length,
        flagged: flags.length,
        flags,
      }),
      { headers: { "Content-Type": "application/json" } },
    );
  } catch (err) {
    console.error("expense-qa-check failed:", err);
    return new Response(
      JSON.stringify({ ok: false, error: (err as Error).message }),
      { status: 500, headers: { "Content-Type": "application/json" } },
    );
  }
});
