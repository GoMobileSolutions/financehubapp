// Slack Events API webhook. Deploy this as a Supabase Edge Function; the resulting
// URL is what you paste into your Slack app's "Event Subscriptions" Request URL.

import { verifySlackSignature, postMessage, deliverAnswer, updateMessage } from "../_shared/slack.ts";
import { answerFinancialQuestion, answerCollectionsQuestion } from "../_shared/claude.ts";
import { createServiceClient, getConnection } from "../_shared/qb-connection.ts";
import type { SlackEvent, SlackEventEnvelope } from "../_shared/types.ts";

const supabase = createServiceClient();
const PROCESS_SECRET = Deno.env.get("CRON_SECRET");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const COLLECTIONS_CHANNEL =
  Deno.env.get("SLACK_COLLECTIONS_CHANNEL") ??
  Deno.env.get("SLACK_DIGEST_CHANNEL") ??
  "";

interface ProcessJob {
  question: string;
  channel: string;
  threadTs?: string;
  slackUserId?: string;
  teamId?: string;
  loadingMessageTs?: string;
  mode?: "finance" | "collections";
}

async function claimSlackEvent(primaryKey: string, extraKeys: string[] = []): Promise<boolean> {
  const { error } = await supabase.from("slack_processed_events").insert({ event_id: primaryKey });
  if (error?.code === "23505") return false;
  if (error) {
    console.error("slack_processed_events insert failed:", error.message);
    return true;
  }
  for (const key of extraKeys) {
    if (!key || key === primaryKey) continue;
    await supabase.from("slack_processed_events").insert({ event_id: key });
  }
  return true;
}

const QUESTION_TIMEOUT_MS = 120_000;

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms);
    promise.then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); },
    );
  });
}

/** Route collections/AR questions to the scoped agent (especially in bB Finances). */
export function shouldUseCollectionsAgent(question: string, channel: string): boolean {
  const collectionsHints =
    /\b(ar|a\/r|accounts?\s*receivable|collect(?:ion|ions|ing)?|overdue|aging|who owes|owes us|unpaid invoice|outstanding|recover(?:ed|y)?|days past due|past due|90\+|contact (?:info|email|phone))\b/i;
  if (collectionsHints.test(question)) return true;

  if (COLLECTIONS_CHANNEL && channel === COLLECTIONS_CHANNEL) {
    // In the collections channel, only keep clearly non-AR questions on the general agent.
    const generalOnly =
      /\b(p&l|profit\s*and\s*loss|balance\s*sheet|cash\s*flow|accounts?\s*payable|ap aging|budget|chase|bank balance|vendor spend)\b/i;
    if (!generalOnly.test(question)) {
      // Ambiguous money questions in this channel → collections
      if (/\b(owe|invoice|customer|paid|payment|due)\b/i.test(question)) return true;
    }
  }
  return false;
}

function shouldHandleEvent(event: SlackEvent): boolean {
  if (event.bot_id) return false;
  if (!event.text || !event.channel) return false;

  const text = event.text.replace(/<@[^>]+>/g, "").trim();
  if (!text) return false;
  if (/has been added to the conversation/i.test(text)) return false;

  if (event.type === "app_mention") return true;

  if (event.type === "message" && !event.subtype) {
    const isIm = event.channel_type === "im" || event.channel.startsWith("D");
    return isIm;
  }

  return false;
}

async function handleQuestion(job: ProcessJob) {
  const { question, channel, threadTs, slackUserId, teamId, loadingMessageTs } = job;
  const mode = job.mode ?? (shouldUseCollectionsAgent(question, channel) ? "collections" : "finance");
  const startedAt = Date.now();
  console.log("handleQuestion start:", mode, question.slice(0, 80));

  try {
    const conn = await getConnection(supabase);
    const agentPromise = mode === "collections"
      ? answerCollectionsQuestion(question, conn, supabase)
      : answerFinancialQuestion(question, conn);
    const { answer, toolCalls } = await withTimeout(
      agentPromise,
      QUESTION_TIMEOUT_MS,
      "QuickBooks lookup",
    );

    await deliverAnswer(channel, answer, threadTs, loadingMessageTs);

    await supabase.from("query_log").insert({
      slack_team_id: teamId,
      slack_channel_id: channel,
      slack_user_id: slackUserId,
      slack_thread_ts: threadTs,
      question: mode === "collections" ? `[collections] ${question}` : question,
      qb_tool_calls: toolCalls,
      answer,
      latency_ms: Date.now() - startedAt,
    });
    console.log("handleQuestion done in", Date.now() - startedAt, "ms", mode);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("handleQuestion failed:", message);
    const errorText = `Sorry — I hit an error pulling that from QuickBooks: ${message}`;
    try {
      if (loadingMessageTs) {
        await updateMessage(channel, loadingMessageTs, errorText, threadTs);
      } else {
        await postMessage(channel, errorText, threadTs);
      }
    } catch (postErr) {
      console.error("Failed to post error to Slack:", postErr);
      await postMessage(channel, errorText, threadTs).catch(() => {});
    }
    await supabase.from("query_log").insert({
      slack_team_id: teamId,
      slack_channel_id: channel,
      slack_user_id: slackUserId,
      slack_thread_ts: threadTs,
      question: mode === "collections" ? `[collections] ${question}` : question,
      error: message,
      latency_ms: Date.now() - startedAt,
    });
  }
}

/** Fire a second function invocation so work isn't dropped when the Slack webhook returns. */
function dispatchProcessJob(job: ProcessJob): void {
  if (!PROCESS_SECRET) {
    console.error("CRON_SECRET not set — cannot dispatch background job");
    return;
  }
  const url = `${SUPABASE_URL}/functions/v1/slack-events?process=1`;
  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-process-secret": PROCESS_SECRET,
      Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
    },
    body: JSON.stringify(job),
  }).catch((err) => console.error("dispatchProcessJob fetch failed:", err));
}

Deno.serve(async (req: Request) => {
  const url = new URL(req.url);

  // Background worker: full question processing in its own invocation (reliable on Supabase).
  if (url.searchParams.get("process") === "1") {
    const secret = req.headers.get("x-process-secret");
    if (!PROCESS_SECRET || secret !== PROCESS_SECRET) {
      return new Response("unauthorized", { status: 401 });
    }
    const job = await req.json() as ProcessJob;
    await handleQuestion(job);
    return Response.json({ ok: true });
  }

  const rawBody = await req.text();

  const validSignature = await verifySlackSignature(
    rawBody,
    req.headers.get("x-slack-request-timestamp"),
    req.headers.get("x-slack-signature"),
  );
  if (!validSignature) {
    return new Response("invalid signature", { status: 401 });
  }

  const payload: SlackEventEnvelope = JSON.parse(rawBody);

  if (payload.type === "url_verification") {
    return new Response(JSON.stringify({ challenge: payload.challenge }), {
      headers: { "Content-Type": "application/json" },
    });
  }

  if (payload.type === "event_callback" && payload.event) {
    const event = payload.event;
    console.log(
      "Slack event received:",
      event.type,
      event.channel,
      event.channel_type ?? "",
      event.subtype ?? "",
      payload.event_id ?? "",
    );

    if (shouldHandleEvent(event)) {
      const primaryKey = event.channel && event.ts
        ? `msg:${event.channel}:${event.ts}`
        : (payload.event_id ?? crypto.randomUUID());

      const claimed = await claimSlackEvent(
        primaryKey,
        [payload.event_id, event.client_msg_id ? `client:${event.client_msg_id}` : ""].filter(Boolean),
      );
      if (!claimed) {
        console.log("Skipping duplicate Slack event:", primaryKey);
        return new Response("ok", { status: 200 });
      }

      const question = event.text!.replace(/<@[^>]+>/g, "").trim();

      if (question.length > 0) {
        const threadTs = event.thread_ts ?? event.ts;
        const mode = shouldUseCollectionsAgent(question, event.channel!)
          ? "collections"
          : "finance";

        let loadingMessageTs: string | undefined;
        try {
          const ackText = mode === "collections"
            ? "Looking up collections / AR in QuickBooks..."
            : "Looking that up in QuickBooks...";
          const ack = await postMessage(event.channel!, ackText, threadTs);
          loadingMessageTs = ack.ts;
        } catch (err) {
          console.error("Failed to post ack message:", err);
        }

        dispatchProcessJob({
          question,
          channel: event.channel!,
          threadTs,
          slackUserId: event.user,
          teamId: payload.team_id,
          loadingMessageTs,
          mode,
        });
      }
    }
  }

  return new Response("ok", { status: 200 });
});
