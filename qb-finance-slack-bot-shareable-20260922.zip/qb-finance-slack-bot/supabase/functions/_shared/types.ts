// Shared types used across the edge function.

export interface QBConnection {
  id: string;
  realm_id: string;
  environment: "sandbox" | "production";
  access_token: string;
  access_token_expires_at: string; // ISO timestamp
  refresh_token: string;
  refresh_token_expires_at: string; // ISO timestamp
  company_name: string | null;
}

export interface QBToolCallRecord {
  tool: string;
  input: unknown;
  result_summary: string;
}

export interface SlackEventEnvelope {
  token?: string;
  team_id?: string;
  api_app_id?: string;
  event?: SlackEvent;
  type: "url_verification" | "event_callback" | string;
  challenge?: string;
  event_id?: string;
  event_time?: number;
}

export interface SlackEvent {
  type: string; // "app_mention" | "message" | ...
  subtype?: string;
  user?: string;
  bot_id?: string;
  text?: string;
  ts?: string;
  channel?: string;
  channel_type?: string; // "channel" | "group" | "im" | "mpim"
  thread_ts?: string;
  event_ts?: string;
  client_msg_id?: string;
}
