// Claude tool-use agent: takes a Slack question, decides which QuickBooks call(s) to
// make, runs them live, and returns a plain-English answer.

import type { SupabaseClient } from "npm:@supabase/supabase-js@2";
import type { QBConnection, QBToolCallRecord } from "./types.ts";
import {
  qbQuery,
  getCompanyInfo,
  getProfitAndLoss,
  getProfitAndLossDetail,
  getBalanceSheet,
  getCashFlow,
  getARAging,
  getARAgingDetail,
  getAPAging,
  getCustomerBalance,
  getCustomerBalanceDetail,
  getCustomerOpenBalance,
  getCustomerIncome,
  getVendorBalance,
  getVendorExpenses,
  getSalesByCustomer,
  findCustomers,
  findVendors,
  getCustomerPayments,
  getCustomerInvoices,
  getUnpaidInvoices,
  getUnpaidBills,
  listBudgets,
  getBudgetVsActual,
  getCashPositionSnapshot,
  getChartOfAccounts,
} from "./quickbooks.ts";
import { getCollectionsLiveSnapshot } from "./collections.ts";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY")!;
const ANTHROPIC_MODEL = Deno.env.get("ANTHROPIC_MODEL") ?? "claude-sonnet-4-5-20250929";
const MAX_TOOL_ITERATIONS = 8;
const MAX_COLLECTIONS_TOOL_ITERATIONS = 4;

const SYSTEM_PROMPT = `You are a financial data assistant for an internal team, answering questions
about their company's live QuickBooks Online data via Slack.

Rules:
- Always use the tools to pull real numbers. Never guess or estimate a financial figure.
- Every tool response is live from QuickBooks (no cache). Trust Header.StartPeriod,
  Header.EndPeriod, and Header.ReportBasis (Cash/Accrual) over assumptions.
- Reports use Cash basis by default (income/expenses when money moves, not when invoiced).
  Always mention "Cash basis" in answers unless Header.ReportBasis says Accrual.
- Dates: use the Pacific "today" provided in the user message. Prefer year-to-date or
  "as of today" when clearly implied; otherwise ask for clarification.
- When answering, briefly state the period and accounting method, e.g.
  "P&L Cash basis Jan 1–Aug 27 2026 (live from QuickBooks)".
- Rank lists (top vendors/customers) by the numeric amount columns — sort descending.
- Slack formatting (required):
  - Use Slack mrkdwn: *bold* for section headings and key totals (single asterisks).
  - Do NOT use Markdown # headers or **double asterisks**.
  - Use Slack emoji shortcodes in headings, e.g. :dollar: :bank: :chart_with_upwards_trend: :warning:
  - Use bullets (•) for lists, not * list markers.
- If a query returns nothing or errors, say so plainly — don't fabricate answers.
- You are read-only.

Accuracy (critical — matches QBO UI):
- Customer "balance / what they owe": find_customers → get_customer_open_balance.
  Use net_open_balance / open_invoice_total. IGNORE Customer.Balance / entity_balance_field
  if it disagrees with open invoices (that field can be stale).
- Bank / Chase / cash: always call get_cash_position_snapshot. For each bank account, show BOTH:
  1) In QuickBooks (books) — Balance Sheet line. Can be negative when For Review / unprocessed
     bank-feed transactions are not yet in the register.
  2) QBO current / dashboard — bank_accounts.qbo_account_current_balance (Account.CurrentBalance).
     This is the current figure QBO stores on the account card / dashboard widget.
  Label them clearly. If they differ, say the gap is typically For Review items.
- Never hide a negative books balance. Never invent a bank-feed number that is not in the tool data.

Tool guidance:
- Customer payments/history: find_customers → get_customer_payments / get_customer_invoices.
- Vendor spend: get_vendor_expenses or find_vendors + unpaid bills.
- Unpaid invoices / bills: get_unpaid_invoices / get_unpaid_bills.
- Expense by category: get_profit_and_loss and/or get_profit_and_loss_detail.
- Budget vs actual: list_budgets → get_budget_vs_actual.
- Cash outlook: get_cash_position_snapshot (label near-term AR/AP as estimate).
- Escape hatch: query_quickbooks.`;

const COLLECTIONS_SYSTEM_PROMPT = `You are a collections / Accounts Receivable assistant for an internal team.
You answer Slack questions about who owes the company money using live QuickBooks data.

Rules:
- Prefer the get_collections_snapshot tool — it fetches full open AR (per invoice) + customer
  contact info + week-over-week recovered vs still-outstanding in ONE call. Call it once;
  do not loop multiple date-range reports.
- Never invent or infer WHY a customer is late — QuickBooks has no such field.
- Never send or draft outbound collection emails; surface contact email/phone for humans only.
- Use Slack mrkdwn: *bold* headings, :emoji: shortcodes, • bullets. No Markdown # or **.
- Mention as-of date from the tool payload.
- Rank by amount or days overdue as the question implies.
- If data is empty, say so plainly.`;

function pacificToday(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Los_Angeles",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}
const dateRangeProps = {
  start_date: { type: "string", description: "YYYY-MM-DD" },
  end_date: { type: "string", description: "YYYY-MM-DD" },
};

const TOOLS = [
  {
    name: "get_profit_and_loss",
    description: "Profit & Loss (income statement) for a date range. Also useful for expense category totals.",
    input_schema: {
      type: "object",
      properties: dateRangeProps,
      required: ["start_date", "end_date"],
    },
  },
  {
    name: "get_profit_and_loss_detail",
    description: "Detailed P&L with line-level transactions — best for expense breakdown by category/account.",
    input_schema: {
      type: "object",
      properties: dateRangeProps,
      required: ["start_date", "end_date"],
    },
  },
  {
    name: "get_balance_sheet",
    description:
      "Balance Sheet as of a date — preferred source for bank/cash/Chase balances (matches QBO UI).",
    input_schema: {
      type: "object",
      properties: { as_of_date: { type: "string", description: "YYYY-MM-DD" } },
      required: ["as_of_date"],
    },
  },
  {
    name: "get_cash_flow",
    description: "Cash Flow statement for a date range.",
    input_schema: {
      type: "object",
      properties: dateRangeProps,
      required: ["start_date", "end_date"],
    },
  },
  {
    name: "get_ar_aging",
    description: "Accounts Receivable aging (who owes us money) as of a date.",
    input_schema: {
      type: "object",
      properties: { as_of_date: { type: "string", description: "YYYY-MM-DD" } },
      required: ["as_of_date"],
    },
  },
  {
    name: "get_ap_aging",
    description: "Accounts Payable aging (who we owe) as of a date.",
    input_schema: {
      type: "object",
      properties: { as_of_date: { type: "string", description: "YYYY-MM-DD" } },
      required: ["as_of_date"],
    },
  },
  {
    name: "get_company_info",
    description: "Basic QuickBooks company info (name, fiscal year, currency).",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "find_customers",
    description:
      "Search customers by name. Do NOT use the Balance field for what they owe — " +
      "call get_customer_open_balance next with their Id.",
    input_schema: {
      type: "object",
      properties: {
        name_contains: { type: "string", description: "Part of the customer display name" },
      },
      required: ["name_contains"],
    },
  },
  {
    name: "get_customer_open_balance",
    description:
      "Authoritative open AR for one customer Id: open invoices + credit memos. " +
      "Use net_open_balance. Prefer this over Customer.Balance or Customer Balance summary.",
    input_schema: {
      type: "object",
      properties: {
        customer_id: { type: "string", description: "QBO Customer Id from find_customers" },
      },
      required: ["customer_id"],
    },
  },
  {
    name: "find_vendors",
    description: "Search vendors by name fragment.",
    input_schema: {
      type: "object",
      properties: {
        name_contains: { type: "string", description: "Part of the vendor display name" },
      },
      required: ["name_contains"],
    },
  },
  {
    name: "get_customer_payments",
    description: "List payments received from a customer Id within a date range (TotalAmt = amount paid).",
    input_schema: {
      type: "object",
      properties: {
        customer_id: { type: "string", description: "QBO Customer Id from find_customers" },
        ...dateRangeProps,
      },
      required: ["customer_id", "start_date", "end_date"],
    },
  },
  {
    name: "get_customer_invoices",
    description: "List invoices for a customer Id; optional date filter. Balance > 0 means unpaid.",
    input_schema: {
      type: "object",
      properties: {
        customer_id: { type: "string" },
        start_date: { type: "string", description: "Optional YYYY-MM-DD" },
        end_date: { type: "string", description: "Optional YYYY-MM-DD" },
      },
      required: ["customer_id"],
    },
  },
  {
    name: "get_customer_income",
    description: "Sales/income by customer report for a date range.",
    input_schema: {
      type: "object",
      properties: dateRangeProps,
      required: ["start_date", "end_date"],
    },
  },
  {
    name: "get_customer_balance",
    description:
      "Open balances by customer report as of a date. For one customer, prefer get_customer_open_balance.",
    input_schema: {
      type: "object",
      properties: { as_of_date: { type: "string", description: "YYYY-MM-DD" } },
      required: ["as_of_date"],
    },
  },
  {
    name: "get_customer_balance_detail",
    description: "Customer Balance Detail report (transaction-level open AR) as of a date.",
    input_schema: {
      type: "object",
      properties: { as_of_date: { type: "string", description: "YYYY-MM-DD" } },
      required: ["as_of_date"],
    },
  },
  {
    name: "get_sales_by_customer",
    description: "Sales by customer summary for a date range — good for ranking top customers.",
    input_schema: {
      type: "object",
      properties: dateRangeProps,
      required: ["start_date", "end_date"],
    },
  },
  {
    name: "get_vendor_expenses",
    description: "Expenses by vendor for a date range — use for top vendors / vendor spend analysis.",
    input_schema: {
      type: "object",
      properties: dateRangeProps,
      required: ["start_date", "end_date"],
    },
  },
  {
    name: "get_vendor_balance",
    description: "Open balances by vendor as of a date.",
    input_schema: {
      type: "object",
      properties: { as_of_date: { type: "string", description: "YYYY-MM-DD" } },
      required: ["as_of_date"],
    },
  },
  {
    name: "get_unpaid_invoices",
    description: "Open customer invoices with Balance above a minimum (default 0).",
    input_schema: {
      type: "object",
      properties: {
        min_balance: { type: "number", description: "Minimum open balance, e.g. 10000" },
        max_results: { type: "number", description: "Max rows (1-100, default 50)" },
      },
    },
  },
  {
    name: "get_unpaid_bills",
    description: "Open vendor bills with Balance above a minimum.",
    input_schema: {
      type: "object",
      properties: {
        min_balance: { type: "number" },
        max_results: { type: "number" },
      },
    },
  },
  {
    name: "list_budgets",
    description: "List budgets configured in QuickBooks. Call before get_budget_vs_actual.",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "get_budget_vs_actual",
    description: "Budget vs Actual report for a budget Id and date range. Requires a budget in QBO.",
    input_schema: {
      type: "object",
      properties: {
        budget_id: { type: "string", description: "Budget Id from list_budgets" },
        ...dateRangeProps,
      },
      required: ["budget_id", "start_date", "end_date"],
    },
  },
  {
    name: "get_cash_position_snapshot",
    description:
      "Cash position: Balance Sheet (In QuickBooks / books) + bank Account.CurrentBalance " +
      "(QBO dashboard/account current) + AR/AP aging. For Chase, always report both bank figures.",
    input_schema: {
      type: "object",
      properties: { as_of_date: { type: "string", description: "YYYY-MM-DD" } },
      required: ["as_of_date"],
    },
  },
  {
    name: "get_chart_of_accounts",
    description:
      "Chart of accounts. For banks, CurrentBalance is the dashboard/account current figure and " +
      "can differ from the Balance Sheet register — use get_cash_position_snapshot and show both.",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "query_quickbooks",
    description:
      "Escape hatch: QBO SQL-like query for anything not covered by named tools. Examples: " +
      "\"SELECT * FROM Invoice WHERE Balance > '0' MAXRESULTS 20\", " +
      "\"SELECT * FROM Customer WHERE DisplayName LIKE '%Acme%'\"",
    input_schema: {
      type: "object",
      properties: {
        query: { type: "string", description: "QBO query string" },
      },
      required: ["query"],
    },
  },
];

const COLLECTIONS_TOOLS = [
  {
    name: "get_collections_snapshot",
    description:
      "ONE-SHOT collections pull: open AR invoices with Product/Service line items, " +
      "customer email/phone, aging buckets, and week-over-week recovered vs still outstanding " +
      "vs the last stored digest snapshot. Prefer this over any other tool.",
    input_schema: {
      type: "object",
      properties: {
        as_of_date: { type: "string", description: "Optional YYYY-MM-DD (defaults to today PT)" },
      },
    },
  },
  {
    name: "get_ar_aging_detail",
    description:
      "Live AR Aging Detail only (open invoices + contacts + line items). " +
      "Use if you already have week-over-week context or only need current outstanding.",
    input_schema: {
      type: "object",
      properties: {
        as_of_date: { type: "string", description: "Optional YYYY-MM-DD" },
      },
    },
  },
  {
    name: "find_customers",
    description: "Search customers by name fragment when the question names a customer.",
    input_schema: {
      type: "object",
      properties: {
        name_contains: { type: "string", description: "Part of the customer display name" },
      },
      required: ["name_contains"],
    },
  },
];

async function runTool(name: string, input: any, conn: QBConnection): Promise<unknown> {
  switch (name) {
    case "get_profit_and_loss":
      return getProfitAndLoss(conn, input.start_date, input.end_date);
    case "get_profit_and_loss_detail":
      return getProfitAndLossDetail(conn, input.start_date, input.end_date);
    case "get_balance_sheet":
      return getBalanceSheet(conn, input.as_of_date);
    case "get_cash_flow":
      return getCashFlow(conn, input.start_date, input.end_date);
    case "get_ar_aging":
      return getARAging(conn, input.as_of_date);
    case "get_ar_aging_detail":
      return getARAgingDetail(conn, input.as_of_date);
    case "get_ap_aging":
      return getAPAging(conn, input.as_of_date);
    case "get_company_info":
      return getCompanyInfo(conn);
    case "find_customers":
      return findCustomers(conn, input.name_contains);
    case "get_customer_open_balance":
      return getCustomerOpenBalance(conn, input.customer_id);
    case "find_vendors":
      return findVendors(conn, input.name_contains);
    case "get_customer_payments":
      return getCustomerPayments(conn, input.customer_id, input.start_date, input.end_date);
    case "get_customer_invoices":
      return getCustomerInvoices(conn, input.customer_id, input.start_date, input.end_date);
    case "get_customer_income":
      return getCustomerIncome(conn, input.start_date, input.end_date);
    case "get_customer_balance":
      return getCustomerBalance(conn, input.as_of_date);
    case "get_customer_balance_detail":
      return getCustomerBalanceDetail(conn, input.as_of_date);
    case "get_sales_by_customer":
      return getSalesByCustomer(conn, input.start_date, input.end_date);
    case "get_vendor_expenses":
      return getVendorExpenses(conn, input.start_date, input.end_date);
    case "get_vendor_balance":
      return getVendorBalance(conn, input.as_of_date);
    case "get_unpaid_invoices":
      return getUnpaidInvoices(conn, input.min_balance ?? 0, input.max_results ?? 50);
    case "get_unpaid_bills":
      return getUnpaidBills(conn, input.min_balance ?? 0, input.max_results ?? 50);
    case "list_budgets":
      return listBudgets(conn);
    case "get_budget_vs_actual":
      return getBudgetVsActual(conn, input.budget_id, input.start_date, input.end_date);
    case "get_cash_position_snapshot":
      return getCashPositionSnapshot(conn, input.as_of_date);
    case "get_chart_of_accounts":
      return getChartOfAccounts(conn);
    case "query_quickbooks":
      return qbQuery(conn, input.query);
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

async function callClaude(
  messages: any[],
  opts: { system: string; tools: typeof TOOLS; maxTokens?: number },
) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: ANTHROPIC_MODEL,
      max_tokens: opts.maxTokens ?? 2000,
      system: opts.system,
      tools: opts.tools,
      messages,
    }),
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Anthropic API error ${res.status}: ${body}`);
  }
  return await res.json();
}

export interface AgentResult {
  answer: string;
  toolCalls: QBToolCallRecord[];
}

async function runAgentLoop(
  question: string,
  conn: QBConnection,
  opts: {
    system: string;
    tools: typeof TOOLS;
    maxIterations: number;
    userPreface: string;
    runNamedTool?: (name: string, input: any) => Promise<unknown>;
  },
): Promise<AgentResult> {
  const today = pacificToday();
  const messages: any[] = [
    {
      role: "user",
      content:
        `Today's date (America/Los_Angeles) is ${today}.\n` +
        `${opts.userPreface}\n\n` +
        `Question: ${question}`,
    },
  ];
  const toolCalls: QBToolCallRecord[] = [];

  for (let i = 0; i < opts.maxIterations; i++) {
    const response = await callClaude(messages, { system: opts.system, tools: opts.tools });
    const toolUseBlocks = response.content.filter((b: any) => b.type === "tool_use");

    if (toolUseBlocks.length === 0) {
      const textBlock = response.content.find((b: any) => b.type === "text");
      return { answer: textBlock?.text ?? "(no answer generated)", toolCalls };
    }

    messages.push({ role: "assistant", content: response.content });

    // Run all tool_use blocks in this turn concurrently (mirrors getCashPositionSnapshot).
    const settled = await Promise.all(
      toolUseBlocks.map(async (block: any) => {
        let resultContent: string;
        try {
          const result = opts.runNamedTool
            ? await opts.runNamedTool(block.name, block.input)
            : await runTool(block.name, block.input, conn);
          const json = JSON.stringify(result);
          resultContent = json.length > 40000 ? json.slice(0, 40000) + "...(truncated)" : json;
          return {
            block,
            resultContent,
            record: {
              tool: block.name,
              input: block.input,
              result_summary: resultContent.slice(0, 400),
            } as QBToolCallRecord,
          };
        } catch (err) {
          resultContent = `ERROR: ${err instanceof Error ? err.message : String(err)}`;
          return {
            block,
            resultContent,
            record: {
              tool: block.name,
              input: block.input,
              result_summary: resultContent,
            } as QBToolCallRecord,
          };
        }
      }),
    );

    const toolResults = [];
    for (const item of settled) {
      toolCalls.push(item.record);
      toolResults.push({
        type: "tool_result",
        tool_use_id: item.block.id,
        content: item.resultContent,
      });
    }
    messages.push({ role: "user", content: toolResults });
  }

  return {
    answer:
      "I made too many QuickBooks calls trying to answer this — try narrowing the question (e.g. a specific customer, date range, or dollar threshold).",
    toolCalls,
  };
}

export async function answerFinancialQuestion(
  question: string,
  conn: QBConnection,
): Promise<AgentResult> {
  return runAgentLoop(question, conn, {
    system: SYSTEM_PROMPT,
    tools: TOOLS,
    maxIterations: MAX_TOOL_ITERATIONS,
    userPreface: "Pull live QuickBooks numbers for this question — do not use memory or estimates.",
  });
}

/** Collections/AR Q&A — scoped tools, one-shot snapshot preferred, concurrent tool results. */
export async function answerCollectionsQuestion(
  question: string,
  conn: QBConnection,
  supabase: SupabaseClient,
): Promise<AgentResult> {
  return runAgentLoop(question, conn, {
    system: COLLECTIONS_SYSTEM_PROMPT,
    tools: COLLECTIONS_TOOLS as typeof TOOLS,
    maxIterations: MAX_COLLECTIONS_TOOL_ITERATIONS,
    userPreface:
      "This is a collections/AR question. Prefer get_collections_snapshot once. " +
      "Do not run multi-month report loops.",
    runNamedTool: async (name, input) => {
      switch (name) {
        case "get_collections_snapshot":
          return getCollectionsLiveSnapshot(supabase, conn, input?.as_of_date);
        case "get_ar_aging_detail":
          return getARAgingDetail(conn, input?.as_of_date);
        case "find_customers":
          return findCustomers(conn, input.name_contains);
        default:
          throw new Error(`Unknown collections tool: ${name}`);
      }
    },
  });
}
