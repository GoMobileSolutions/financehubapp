import { createClient, SupabaseClient } from "npm:@supabase/supabase-js@2";
import { refreshAccessToken } from "./quickbooks.ts";
import type { QBConnection } from "./types.ts";

export async function getConnection(supabase: SupabaseClient): Promise<QBConnection> {
  const { data, error } = await supabase.from("qb_connections").select("*").limit(1).single();
  if (error || !data) throw new Error(`No QuickBooks connection configured: ${error?.message}`);

  const row = data as QBConnection;
  const refreshed = await refreshAccessToken(row);
  if (!refreshed) return row;

  const { error: updateError } = await supabase
    .from("qb_connections")
    .update({
      access_token: refreshed.access_token,
      refresh_token: refreshed.refresh_token,
      access_token_expires_at: new Date(Date.now() + refreshed.expires_in * 1000).toISOString(),
      refresh_token_expires_at: new Date(
        Date.now() + refreshed.x_refresh_token_expires_in * 1000,
      ).toISOString(),
    })
    .eq("id", row.id);
  if (updateError) throw new Error(`Failed to persist refreshed QB token: ${updateError.message}`);

  return { ...row, access_token: refreshed.access_token, refresh_token: refreshed.refresh_token };
}

export function createServiceClient(): SupabaseClient {
  const url = Deno.env.get("SUPABASE_URL")!;
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(url, key);
}
