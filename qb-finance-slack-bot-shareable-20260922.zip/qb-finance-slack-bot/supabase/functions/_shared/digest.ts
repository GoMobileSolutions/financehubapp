// Scheduled digest helpers: Pacific-time scheduling + Claude prompts per report type.

export type DigestType = "daily" | "weekly" | "monthly";

export interface PTDateTime {
  date: string; // YYYY-MM-DD in America/Los_Angeles
  hour: number; // 0-23
  weekday: number; // 0=Sun .. 6=Sat
  year: number;
  month: number; // 1-12
  day: number;
}

const PT = "America/Los_Angeles";

export function getPTDateTime(now = new Date()): PTDateTime {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: PT,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    hour12: false,
    weekday: "short",
  }).formatToParts(now);

  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "";
  const weekdayMap: Record<string, number> = {
    Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6,
  };

  const year = parseInt(get("year"), 10);
  const month = parseInt(get("month"), 10);
  const day = parseInt(get("day"), 10);
  let hour = parseInt(get("hour"), 10);
  if (hour === 24) hour = 0;

  return {
    date: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`,
    hour,
    weekday: weekdayMap[get("weekday")] ?? 0,
    year,
    month,
    day,
  };
}

function addDaysYMD(year: number, month: number, day: number, delta: number): string {
  const d = new Date(Date.UTC(year, month - 1, day + delta));
  return d.toISOString().slice(0, 10);
}

function daysInMonth(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

export function isLastDayOfMonthPT(pt: PTDateTime): boolean {
  return pt.day === daysInMonth(pt.year, pt.month);
}

/** Which digests should run at 6 PM PT on this calendar day? */
export function digestsDueAt6pmPT(pt: PTDateTime): DigestType[] {
  if (pt.hour !== 18) return [];

  const due: DigestType[] = [];

  // Mon-Fri daily snapshot
  if (pt.weekday >= 1 && pt.weekday <= 5) due.push("daily");

  // Friday weekly (prior Mon–Sun)
  if (pt.weekday === 5) due.push("weekly");

  // Last calendar day of month
  if (isLastDayOfMonthPT(pt)) due.push("monthly");

  return due;
}

function previousWeekRange(pt: PTDateTime): { start: string; end: string } {
  // Current week's Monday in PT, then back 7 days for prior Mon and +6 for prior Sun.
  const daysSinceMonday = pt.weekday === 0 ? 6 : pt.weekday - 1;
  const thisWeekMonday = addDaysYMD(pt.year, pt.month, pt.day, -daysSinceMonday);
  const prevMonday = addDaysYMD(
    parseInt(thisWeekMonday.slice(0, 4), 10),
    parseInt(thisWeekMonday.slice(5, 7), 10),
    parseInt(thisWeekMonday.slice(8, 10), 10),
    -7,
  );
  const prevSunday = addDaysYMD(
    parseInt(prevMonday.slice(0, 4), 10),
    parseInt(prevMonday.slice(5, 7), 10),
    parseInt(prevMonday.slice(8, 10), 10),
    6,
  );
  return { start: prevMonday, end: prevSunday };
}

function monthRange(pt: PTDateTime): { start: string; end: string; label: string } {
  const start = `${pt.year}-${String(pt.month).padStart(2, "0")}-01`;
  const end = `${pt.year}-${String(pt.month).padStart(2, "0")}-${String(pt.day).padStart(2, "0")}`;
  const label = new Intl.DateTimeFormat("en-US", { timeZone: PT, month: "long", year: "numeric" })
    .format(new Date(Date.UTC(pt.year, pt.month - 1, pt.day)));
  return { start, end, label };
}

export function digestTitle(type: DigestType, pt: PTDateTime): string {
  switch (type) {
    case "daily":
      return `Daily finance snapshot — ${pt.date} (PT)`;
    case "weekly": {
      const { start, end } = previousWeekRange(pt);
      return `Weekly finance digest — ${start} to ${end} (PT)`;
    }
    case "monthly": {
      const { label } = monthRange(pt);
      return `Monthly finance digest — ${label} (PT)`;
    }
  }
}

export function digestQuestion(type: DigestType, pt: PTDateTime): string {
  switch (type) {
    case "daily":
      return `Generate a concise daily finance snapshot for Slack as of ${pt.date} (Pacific time).
Use Cash basis reports (money actually received/paid).
Include:
- Current cash position (cash and bank accounts from the balance sheet or equivalent)
- AR aging summary as of today (total outstanding and key buckets if available)
For each bank (especially Chase), show BOTH In QuickBooks (Balance Sheet / register) AND
QBO current/dashboard (Account.CurrentBalance). If Chase books are negative, still show that
number, plus the dashboard current balance, and note For Review / unprocessed feed items.
Slack format: *bold headings*, emoji shortcodes (:dollar: :bank: :chart_with_upwards_trend:), • bullets.`;

    case "weekly": {
      const { start, end } = previousWeekRange(pt);
      return `Generate a weekly finance digest for Slack covering ${start} through ${end} (Pacific time, prior Mon–Sun week).
Use Cash basis P&L (money actually received/paid).
Include:
- Profit & Loss for that full week
- AR aging summary as of ${end}
Slack format: *bold headings*, emoji shortcodes, • bullets.`;
    }

    case "monthly": {
      const { start, end, label } = monthRange(pt);
      return `Generate a monthly finance digest for Slack for ${label} (${start} through ${end}, Pacific time).
Use Cash basis for P&L, Balance Sheet, and Cash Flow (money actually received/paid).
Include:
- Full Profit & Loss for the month
- Balance Sheet as of ${end}
- Cash Flow statement for the month
For bank accounts on the Balance Sheet (especially Chase), also include QBO current/dashboard
balance from get_cash_position_snapshot bank_accounts when showing cash.
Slack format: *bold headings*, emoji shortcodes (:dollar: :bank: :chart_with_upwards_trend:), • bullets.`;
    }
  }
}
