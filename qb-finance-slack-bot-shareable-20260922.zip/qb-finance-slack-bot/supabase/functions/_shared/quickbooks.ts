import type { QBConnection } from "./types.ts";

const QB_CLIENT_ID = Deno.env.get("QB_CLIENT_ID")!;
const QB_CLIENT_SECRET = Deno.env.get("QB_CLIENT_SECRET")!;
// Report basis for P&L, Balance Sheet, etc. Default Cash (money actually received/paid).
// Set QB_ACCOUNTING_METHOD=Accrual to match accrual books instead.
const QB_ACCOUNTING_METHOD = Deno.env.get("QB_ACCOUNTING_METHOD") as "Accrual" | "Cash" | undefined;
const QB_MINOR_VERSION = Deno.env.get("QB_MINOR_VERSION") ?? "75";

const TOKEN_ENDPOINT = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer";

function apiBase(environment: "sandbox" | "production") {
  return environment === "sandbox"
    ? "https://sandbox-quickbooks.api.intuit.com"
    : "https://quickbooks.api.intuit.com";
}

export async function refreshAccessToken(
  conn: QBConnection,
): Promise<{ access_token: string; refresh_token: string; expires_in: number; x_refresh_token_expires_in: number } | null> {
  const expiresAt = new Date(conn.access_token_expires_at).getTime();
  if (expiresAt - Date.now() > 60_000) {
    return null;
  }

  const basicAuth = btoa(`${QB_CLIENT_ID}:${QB_CLIENT_SECRET}`);
  const res = await fetch(TOKEN_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
      Authorization: `Basic ${basicAuth}`,
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: conn.refresh_token,
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`QBO token refresh failed (${res.status}): ${body}`);
  }

  return await res.json();
}

async function qbFetch(conn: QBConnection, path: string, searchParams?: Record<string, string>) {
  const url = new URL(`${apiBase(conn.environment)}/v3/company/${conn.realm_id}/${path}`);
  url.searchParams.set("minorversion", QB_MINOR_VERSION);
  if (searchParams) {
    for (const [k, v] of Object.entries(searchParams)) {
      if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, v);
    }
  }
  const res = await fetch(url.toString(), {
    headers: {
      Authorization: `Bearer ${conn.access_token}`,
      Accept: "application/json",
    },
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`QBO API error ${res.status} on ${path}: ${body}`);
  }
  return await res.json();
}

export async function qbQuery(conn: QBConnection, query: string) {
  return qbFetch(conn, "query", { query });
}

/** Report basis for QBO reports. Defaults to Cash unless QB_ACCOUNTING_METHOD is set. */
export async function getReportAccountingMethod(_conn: QBConnection): Promise<"Accrual" | "Cash"> {
  if (QB_ACCOUNTING_METHOD === "Accrual" || QB_ACCOUNTING_METHOD === "Cash") {
    return QB_ACCOUNTING_METHOD;
  }
  return "Cash";
}

function withAccountingMethod(
  method: "Accrual" | "Cash",
  params: Record<string, string> = {},
): Record<string, string> {
  return { accounting_method: method, ...params };
}

/**
 * Compact a QBO report JSON so Claude sees Header (dates/basis) + line totals,
 * instead of a huge nested payload that gets truncated mid-report.
 */
export function compactQboReport(report: any, maxLines = 120): Record<string, unknown> {
  const header = report?.Header ?? {};
  const lines: Array<{ name: string; values: string[]; type?: string }> = [];

  function walk(rows: any[] | undefined) {
    if (!rows || lines.length >= maxLines) return;
    for (const row of rows) {
      if (lines.length >= maxLines) break;
      const summary = row?.Summary ?? row;
      const colData = summary?.ColData as Array<{ value?: string }> | undefined;
      if (colData?.length) {
        const name = colData[0]?.value ?? "";
        const values = colData.slice(1).map((c) => c?.value ?? "");
        if (name || values.some((v) => v)) {
          lines.push({ name, values, type: row?.type });
        }
      }
      if (row?.Rows?.Row) walk(row.Rows.Row);
    }
  }

  walk(report?.Rows?.Row);

  return {
    live_from_quickbooks: true,
    fetched_at_utc: new Date().toISOString(),
    header: {
      ReportName: header.ReportName,
      ReportBasis: header.ReportBasis,
      StartPeriod: header.StartPeriod,
      EndPeriod: header.EndPeriod,
      DateMacro: header.DateMacro,
      Currency: header.Currency,
      Time: header.Time,
      Option: header.Option,
    },
    columns: (report?.Columns?.Column ?? []).map((c: any) => c?.ColTitle ?? c?.ColType),
    lines,
    truncated: lines.length >= maxLines,
  };
}

async function report(conn: QBConnection, path: string, params: Record<string, string>) {
  const accountingMethod = await getReportAccountingMethod(conn);
  const raw = await qbFetch(conn, path, withAccountingMethod(accountingMethod, params));
  return compactQboReport(raw);
}

export async function getCompanyInfo(conn: QBConnection) {
  return qbFetch(conn, `companyinfo/${conn.realm_id}`);
}

export async function getProfitAndLoss(conn: QBConnection, startDate: string, endDate: string) {
  return report(conn, "reports/ProfitAndLoss", { start_date: startDate, end_date: endDate });
}

export async function getBalanceSheet(conn: QBConnection, asOfDate: string) {
  return report(conn, "reports/BalanceSheet", { date: asOfDate });
}

export async function getCashFlow(conn: QBConnection, startDate: string, endDate: string) {
  return report(conn, "reports/CashFlow", { start_date: startDate, end_date: endDate });
}

export async function getARAging(conn: QBConnection, asOfDate: string) {
  return report(conn, "reports/AgedReceivables", { report_date: asOfDate });
}

export type AgingBucket = "current" | "1-30" | "31-60" | "61-90" | "91+";

export interface ARLineItem {
  name: string;
  amount: number;
}

export interface ARAgingInvoiceRow {
  invoice_id: string;
  invoice_number: string;
  invoice_date: string;
  due_date: string;
  days_overdue: number;
  aging_bucket: AgingBucket;
  balance: number;
  original_amount: number;
  customer_id: string;
  customer_name: string;
  contact_email: string | null;
  contact_phone: string | null;
  product_service: string;
  line_items: ARLineItem[];
}

export interface ARAgingDetailResult {
  live_from_quickbooks: true;
  fetched_at_utc: string;
  as_of_date: string;
  total_outstanding: number;
  buckets: Record<AgingBucket, { amount: number; percent: number; count: number }>;
  invoices: ARAgingInvoiceRow[];
  note: string;
  /** Compact AgedReceivables summary when available (cross-check only). */
  aging_summary_compact?: Record<string, unknown>;
}

function parseYmd(ymd: string): Date {
  const [y, m, d] = ymd.split("-").map((n) => parseInt(n, 10));
  return new Date(Date.UTC(y, m - 1, d));
}

function daysBetweenYmd(earlier: string, later: string): number {
  const a = parseYmd(earlier);
  const b = parseYmd(later);
  return Math.floor((b.getTime() - a.getTime()) / 86_400_000);
}

export function agingBucketForDaysOverdue(daysOverdue: number): AgingBucket {
  if (daysOverdue <= 0) return "current";
  if (daysOverdue <= 30) return "1-30";
  if (daysOverdue <= 60) return "31-60";
  if (daysOverdue <= 90) return "61-90";
  return "91+";
}

function emptyBuckets(): Record<AgingBucket, { amount: number; percent: number; count: number }> {
  return {
    current: { amount: 0, percent: 0, count: 0 },
    "1-30": { amount: 0, percent: 0, count: 0 },
    "31-60": { amount: 0, percent: 0, count: 0 },
    "61-90": { amount: 0, percent: 0, count: 0 },
    "91+": { amount: 0, percent: 0, count: 0 },
  };
}

function extractInvoiceLineItems(invoice: Record<string, unknown>): ARLineItem[] {
  const lines = (invoice.Line as Array<Record<string, unknown>> | undefined) ?? [];
  const items: ARLineItem[] = [];
  for (const line of lines) {
    const detailType = String(line.DetailType ?? "");
    if (detailType !== "SalesItemLineDetail" && detailType !== "GroupLineDetail") continue;
    const detail = (line.SalesItemLineDetail ?? line.GroupLineDetail) as
      | Record<string, unknown>
      | undefined;
    const itemRef = detail?.ItemRef as { name?: string; value?: string } | undefined;
    const name =
      itemRef?.name ||
      (typeof line.Description === "string" ? line.Description : "") ||
      "Unknown";
    if (!name.trim()) continue;
    items.push({ name: name.trim(), amount: Number(line.Amount ?? 0) });
  }
  return items;
}

async function queryAllOpenInvoices(conn: QBConnection): Promise<Array<Record<string, unknown>>> {
  const pageSize = 500;
  let start = 1;
  const all: Array<Record<string, unknown>> = [];
  for (;;) {
    const result = await qbQuery(
      conn,
      `SELECT * FROM Invoice WHERE Balance > '0' STARTPOSITION ${start} MAXRESULTS ${pageSize}`,
    );
    const batch = (result?.QueryResponse?.Invoice ?? []) as Array<Record<string, unknown>>;
    all.push(...batch);
    if (batch.length < pageSize) break;
    start += pageSize;
    if (start > 5000) break; // safety cap
  }
  return all;
}

/** Fetch Customer contact fields for a set of Ids (batched, parallel). */
export async function getCustomersContactInfo(
  conn: QBConnection,
  customerIds: string[],
): Promise<
  Map<
    string,
    {
      id: string;
      display_name: string;
      email: string | null;
      phone: string | null;
    }
  >
> {
  const unique = [...new Set(customerIds.filter(Boolean))];
  const map = new Map<
    string,
    { id: string; display_name: string; email: string | null; phone: string | null }
  >();
  if (unique.length === 0) return map;

  const chunkSize = 30;
  const chunks: string[][] = [];
  for (let i = 0; i < unique.length; i += chunkSize) {
    chunks.push(unique.slice(i, i + chunkSize));
  }

  const results = await Promise.all(
    chunks.map(async (chunk) => {
      const inList = chunk.map((id) => `'${escapeQboString(id)}'`).join(", ");
      try {
        return await qbQuery(
          conn,
          `SELECT Id, DisplayName, PrimaryEmailAddr, PrimaryPhone, Mobile, AlternatePhone ` +
            `FROM Customer WHERE Id IN (${inList}) MAXRESULTS ${chunk.length}`,
        );
      } catch {
        // Some realms reject IN — fall back to per-id fetches for this chunk.
        const fallback = await Promise.all(
          chunk.map((id) =>
            qbQuery(
              conn,
              `SELECT Id, DisplayName, PrimaryEmailAddr, PrimaryPhone, Mobile, AlternatePhone ` +
                `FROM Customer WHERE Id = '${escapeQboString(id)}'`,
            ).catch(() => null),
          ),
        );
        return {
          QueryResponse: {
            Customer: fallback.flatMap((r) => r?.QueryResponse?.Customer ?? []),
          },
        };
      }
    }),
  );

  for (const result of results) {
    for (const c of (result?.QueryResponse?.Customer ?? []) as Array<Record<string, any>>) {
      const email = c.PrimaryEmailAddr?.Address ?? null;
      const phone =
        c.PrimaryPhone?.FreeFormNumber ??
        c.Mobile?.FreeFormNumber ??
        c.AlternatePhone?.FreeFormNumber ??
        null;
      map.set(String(c.Id), {
        id: String(c.Id),
        display_name: String(c.DisplayName ?? ""),
        email: email ? String(email) : null,
        phone: phone ? String(phone) : null,
      });
    }
  }
  return map;
}

/**
 * Full AR Aging Detail for collections: open invoices (Balance > 0) with line-item
 * Product/Service names + customer email/phone, fetched concurrently.
 *
 * Uses Invoice query (not only AgedReceivableDetail report) so we get line items;
 * aging buckets are computed from DueDate vs as_of_date.
 */
export async function getARAgingDetail(
  conn: QBConnection,
  asOfDate?: string,
): Promise<ARAgingDetailResult> {
  const asOf =
    asOfDate ??
    new Intl.DateTimeFormat("en-CA", {
      timeZone: "America/Los_Angeles",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date());

  // One invoice query + optional summary report in parallel (not sequential month loops).
  const [invoices, agingSummary] = await Promise.all([
    queryAllOpenInvoices(conn),
    getARAging(conn, asOf).catch(() => null),
  ]);

  const customerIds = invoices
    .map((inv) => (inv.CustomerRef as { value?: string } | undefined)?.value)
    .filter((id): id is string => Boolean(id));

  const customers = await getCustomersContactInfo(conn, customerIds);

  const rows: ARAgingInvoiceRow[] = [];
  for (const inv of invoices) {
    const customerRef = inv.CustomerRef as { value?: string; name?: string } | undefined;
    const customerId = String(customerRef?.value ?? "");
    const contact = customers.get(customerId);
    const dueDate = String(inv.DueDate ?? inv.TxnDate ?? asOf);
    const invoiceDate = String(inv.TxnDate ?? "");
    const daysOverdue = Math.max(0, daysBetweenYmd(dueDate, asOf));
    const lineItems = extractInvoiceLineItems(inv);
    const productService = lineItems.map((l) => l.name).filter(Boolean).join(", ") ||
      "(no product/service lines)";

    rows.push({
      invoice_id: String(inv.Id ?? ""),
      invoice_number: String(inv.DocNumber ?? ""),
      invoice_date: invoiceDate,
      due_date: dueDate,
      days_overdue: daysOverdue,
      aging_bucket: agingBucketForDaysOverdue(daysOverdue),
      balance: Number(inv.Balance ?? 0),
      original_amount: Number(inv.TotalAmt ?? 0),
      customer_id: customerId,
      customer_name: contact?.display_name || String(customerRef?.name ?? "Unknown"),
      contact_email: contact?.email ?? null,
      contact_phone: contact?.phone ?? null,
      product_service: productService,
      line_items: lineItems,
    });
  }

  rows.sort((a, b) => b.days_overdue - a.days_overdue || b.balance - a.balance);

  const buckets = emptyBuckets();
  let total = 0;
  for (const row of rows) {
    total += row.balance;
    buckets[row.aging_bucket].amount += row.balance;
    buckets[row.aging_bucket].count += 1;
  }
  for (const key of Object.keys(buckets) as AgingBucket[]) {
    buckets[key].percent = total > 0 ? Math.round((buckets[key].amount / total) * 1000) / 10 : 0;
  }

  const result: ARAgingDetailResult = {
    live_from_quickbooks: true,
    fetched_at_utc: new Date().toISOString(),
    as_of_date: asOf,
    total_outstanding: total,
    buckets,
    invoices: rows,
    note:
      "Open AR from Invoice.Balance > 0 with line-item Product/Service and Customer contact. " +
      "Aging buckets from DueDate vs as_of_date. Do not invent reasons for lateness. " +
      (agingSummary
        ? "AgedReceivables summary also fetched for cross-check (see aging_summary_compact)."
        : "AgedReceivables summary unavailable."),
  };
  if (agingSummary) result.aging_summary_compact = agingSummary;
  return result;
}

/**
 * Reconstruct open AR as of a historical date via AgedReceivableDetail report.
 * Used for backfilled week-over-week compares when we don't have a stored snapshot.
 */
export async function getARAgingDetailFromReport(
  conn: QBConnection,
  asOfDate: string,
): Promise<ARAgingDetailResult> {
  const accountingMethod = await getReportAccountingMethod(conn);
  const raw = await qbFetch(
    conn,
    "reports/AgedReceivableDetail",
    withAccountingMethod(accountingMethod, {
      report_date: asOfDate,
    }),
  );

  const colTypes: string[] = (raw?.Columns?.Column ?? []).map((c: any) =>
    String(c?.ColType ?? c?.MetaData?.[0]?.Value ?? c?.ColTitle ?? "").toLowerCase(),
  );

  const idx = (...names: string[]) => {
    for (const name of names) {
      const i = colTypes.findIndex((t) => t.includes(name));
      if (i >= 0) return i;
    }
    return -1;
  };

  const iDate = idx("tx_date", "date");
  const iType = idx("txn_type", "type");
  const iDoc = idx("doc_num", "num");
  const iCust = idx("cust_name", "name", "customer");
  const iDue = idx("due_date");
  const iPast = idx("past_due", "aging");
  const iOpen = idx("open_bal", "subt_open", "open");
  const iAmt = idx("subt_amount", "amount");

  const rows: ARAgingInvoiceRow[] = [];
  let currentCustomer = "";

  function walk(list: any[] | undefined) {
    if (!list) return;
    for (const row of list) {
      const group = String(row?.group ?? "");
      if (row?.type === "Section" && group === "Customer") {
        const header = row?.Header?.ColData?.[0]?.value;
        if (header) currentCustomer = String(header);
      }

      const colData = row?.ColData as Array<{ value?: string; id?: string }> | undefined;
      if (row?.type === "Data" && colData?.length) {
        const txnType = iType >= 0 ? String(colData[iType]?.value ?? "") : "";
        if (txnType && /payment|credit|journal|deposit/i.test(txnType)) {
          // skip non-invoice rows when type is present
        } else {
          const docNum = iDoc >= 0 ? String(colData[iDoc]?.value ?? "").trim() : "";
          const openBal = iOpen >= 0
            ? Number(String(colData[iOpen]?.value ?? "0").replace(/,/g, ""))
            : iAmt >= 0
            ? Number(String(colData[iAmt]?.value ?? "0").replace(/,/g, ""))
            : 0;
          if (openBal > 0.009 && (docNum || colData.some((c) => c?.id))) {
            const custName =
              (iCust >= 0 ? String(colData[iCust]?.value ?? "") : "") || currentCustomer || "Unknown";
            const dueDate = iDue >= 0 ? String(colData[iDue]?.value ?? "") : "";
            const invoiceDate = iDate >= 0 ? String(colData[iDate]?.value ?? "") : "";
            const pastDueRaw = iPast >= 0 ? String(colData[iPast]?.value ?? "") : "";
            const pastDueNum = Number(pastDueRaw.replace(/,/g, ""));
            const daysOverdue = Number.isFinite(pastDueNum)
              ? Math.max(0, pastDueNum)
              : dueDate
              ? Math.max(0, daysBetweenYmd(dueDate, asOfDate))
              : 0;
            const txnId =
              colData.find((c) => c?.id && /^\d+$/.test(String(c.id)))?.id ??
              (iDoc >= 0 ? colData[iDoc]?.id : undefined) ??
              docNum;

            rows.push({
              invoice_id: String(txnId || docNum),
              invoice_number: docNum,
              invoice_date: invoiceDate,
              due_date: dueDate || invoiceDate || asOfDate,
              days_overdue: daysOverdue,
              aging_bucket: agingBucketForDaysOverdue(daysOverdue),
              balance: openBal,
              original_amount: iAmt >= 0
                ? Number(String(colData[iAmt]?.value ?? openBal).replace(/,/g, ""))
                : openBal,
              customer_id: String(colData[iCust]?.id ?? ""),
              customer_name: custName,
              contact_email: null,
              contact_phone: null,
              product_service: "(from AR Aging Detail report)",
              line_items: [],
            });
          }
        }
      }

      if (row?.Rows?.Row) walk(row.Rows.Row);
    }
  }

  walk(raw?.Rows?.Row);

  // Dedupe by invoice_number/id (report can repeat section totals).
  const byKey = new Map<string, ARAgingInvoiceRow>();
  for (const r of rows) {
    if (r.balance <= 0) continue;
    const key = r.invoice_number || r.invoice_id;
    const prev = byKey.get(key);
    if (!prev || r.balance > prev.balance) byKey.set(key, r);
  }
  const invoices = [...byKey.values()].sort(
    (a, b) => b.days_overdue - a.days_overdue || b.balance - a.balance,
  );

  const buckets = emptyBuckets();
  let total = 0;
  for (const row of invoices) {
    total += row.balance;
    buckets[row.aging_bucket].amount += row.balance;
    buckets[row.aging_bucket].count += 1;
  }
  for (const key of Object.keys(buckets) as AgingBucket[]) {
    buckets[key].percent = total > 0 ? Math.round((buckets[key].amount / total) * 1000) / 10 : 0;
  }

  return {
    live_from_quickbooks: true,
    fetched_at_utc: new Date().toISOString(),
    as_of_date: asOfDate,
    total_outstanding: total,
    buckets,
    invoices,
    note:
      `Historical AR from AgedReceivableDetail report_date=${asOfDate}. ` +
      "Used for backfilled recovery stats when no stored snapshot exists.",
  };
}

/** Map DocNumber → Invoice Id so historical report rows join to live invoice Ids. */
export async function mapInvoiceDocNumbersToIds(
  conn: QBConnection,
): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  const pageSize = 500;
  let start = 1;
  for (;;) {
    const result = await qbQuery(
      conn,
      `SELECT Id, DocNumber FROM Invoice STARTPOSITION ${start} MAXRESULTS ${pageSize}`,
    );
    const batch = (result?.QueryResponse?.Invoice ?? []) as Array<{
      Id?: string;
      DocNumber?: string;
    }>;
    for (const inv of batch) {
      if (inv.DocNumber && inv.Id) map.set(String(inv.DocNumber), String(inv.Id));
    }
    if (batch.length < pageSize) break;
    start += pageSize;
    if (start > 5000) break;
  }
  return map;
}

export async function getAPAging(conn: QBConnection, asOfDate: string) {
  return report(conn, "reports/AgedPayables", { report_date: asOfDate });
}

export async function getCustomerBalance(conn: QBConnection, asOfDate: string) {
  return report(conn, "reports/CustomerBalance", { report_date: asOfDate });
}

/** Open AR detail — matches QBO Customer Balance Detail better than Customer.Balance. */
export async function getCustomerBalanceDetail(conn: QBConnection, asOfDate: string) {
  return report(conn, "reports/CustomerBalanceDetail", { report_date: asOfDate });
}

/**
 * Authoritative open balance for one customer:
 * sum of Invoice.Balance > 0 (what QBO treats as unpaid AR).
 * Do NOT trust Customer.Balance alone — it can lag or include credits differently than the UI.
 */
export async function getCustomerOpenBalance(conn: QBConnection, customerId: string) {
  const id = escapeQboString(customerId);
  const [customerRes, openInvoices, creditMemos] = await Promise.all([
    qbQuery(
      conn,
      `SELECT Id, DisplayName, Balance, Active FROM Customer WHERE Id = '${id}'`,
    ),
    qbQuery(
      conn,
      `SELECT Id, DocNumber, TxnDate, DueDate, TotalAmt, Balance, CustomerRef FROM Invoice ` +
        `WHERE CustomerRef = '${id}' AND Balance > '0' MAXRESULTS 500`,
    ),
    qbQuery(
      conn,
      `SELECT Id, DocNumber, TxnDate, TotalAmt, RemainingCredit, CustomerRef FROM CreditMemo ` +
        `WHERE CustomerRef = '${id}' AND RemainingCredit > '0' MAXRESULTS 100`,
    ).catch(() => null),
  ]);

  const customer = customerRes?.QueryResponse?.Customer?.[0] ?? null;
  const invoices = openInvoices?.QueryResponse?.Invoice ?? [];
  const credits = creditMemos?.QueryResponse?.CreditMemo ?? [];
  const openInvoiceTotal = invoices.reduce(
    (sum: number, inv: { Balance?: number | string }) => sum + Number(inv.Balance ?? 0),
    0,
  );
  const openCreditTotal = credits.reduce(
    (sum: number, cm: { RemainingCredit?: number | string }) => sum + Number(cm.RemainingCredit ?? 0),
    0,
  );

  return {
    live_from_quickbooks: true,
    fetched_at_utc: new Date().toISOString(),
    customer,
    entity_balance_field: customer?.Balance ?? null,
    entity_balance_warning:
      "Customer.Balance is a cached entity field and can disagree with the UI. " +
      "Use open_invoice_total (minus open credits) as the source of truth for what they owe.",
    open_invoices: invoices,
    open_invoice_total: openInvoiceTotal,
    open_credit_memos: credits,
    open_credit_total: openCreditTotal,
    net_open_balance: openInvoiceTotal - openCreditTotal,
  };
}

export async function getCustomerIncome(conn: QBConnection, startDate: string, endDate: string) {
  return report(conn, "reports/CustomerIncome", { start_date: startDate, end_date: endDate });
}

export async function getVendorBalance(conn: QBConnection, asOfDate: string) {
  return report(conn, "reports/VendorBalance", { report_date: asOfDate });
}

export async function getVendorExpenses(conn: QBConnection, startDate: string, endDate: string) {
  return report(conn, "reports/VendorExpenses", { start_date: startDate, end_date: endDate });
}

export async function getSalesByCustomer(conn: QBConnection, startDate: string, endDate: string) {
  return report(conn, "reports/SalesByCustomer", { start_date: startDate, end_date: endDate });
}

function escapeQboString(value: string): string {
  return value.replace(/'/g, "\\'");
}

export async function getProfitAndLossDetail(conn: QBConnection, startDate: string, endDate: string) {
  const accountingMethod = await getReportAccountingMethod(conn);
  const raw = await qbFetch(
    conn,
    "reports/ProfitAndLossDetail",
    withAccountingMethod(accountingMethod, { start_date: startDate, end_date: endDate }),
  );
  return compactQboReport(raw, 200);
}

export async function findCustomers(conn: QBConnection, nameContains: string) {
  const q = escapeQboString(nameContains.trim());
  const result = await qbQuery(
    conn,
    `SELECT Id, DisplayName, Balance, Active FROM Customer WHERE DisplayName LIKE '%${q}%' MAXRESULTS 25`,
  );
  return {
    ...result,
    note:
      "The Balance field on each customer can be stale vs QBO UI. " +
      "For what a customer owes, call get_customer_open_balance with their Id.",
  };
}

export async function findVendors(conn: QBConnection, nameContains: string) {
  const q = escapeQboString(nameContains.trim());
  return qbQuery(
    conn,
    `SELECT Id, DisplayName, Balance, Active FROM Vendor WHERE DisplayName LIKE '%${q}%' MAXRESULTS 25`,
  );
}

export async function getCustomerPayments(
  conn: QBConnection,
  customerId: string,
  startDate: string,
  endDate: string,
) {
  const id = escapeQboString(customerId);
  return qbQuery(
    conn,
    `SELECT Id, TxnDate, TotalAmt, CustomerRef, PaymentRefNum FROM Payment ` +
      `WHERE CustomerRef = '${id}' AND TxnDate >= '${startDate}' AND TxnDate <= '${endDate}' ` +
      `MAXRESULTS 500`,
  );
}

/** All customer payments in a date range (collections cash collected). */
export async function getPaymentsInDateRange(
  conn: QBConnection,
  startDate: string,
  endDate: string,
) {
  const result = await qbQuery(
    conn,
    `SELECT Id, TxnDate, TotalAmt, CustomerRef, PaymentRefNum FROM Payment ` +
      `WHERE TxnDate >= '${startDate}' AND TxnDate <= '${endDate}' MAXRESULTS 500`,
  );
  const payments = (result?.QueryResponse?.Payment ?? []) as Array<Record<string, any>>;
  const total = payments.reduce((s, p) => s + Number(p.TotalAmt ?? 0), 0);
  return {
    live_from_quickbooks: true,
    fetched_at_utc: new Date().toISOString(),
    start_date: startDate,
    end_date: endDate,
    payment_count: payments.length,
    total_collected: total,
    payments: payments.map((p) => ({
      id: String(p.Id ?? ""),
      date: String(p.TxnDate ?? ""),
      amount: Number(p.TotalAmt ?? 0),
      customer_id: String(p.CustomerRef?.value ?? ""),
      customer_name: String(p.CustomerRef?.name ?? ""),
      payment_ref: p.PaymentRefNum ? String(p.PaymentRefNum) : null,
    })),
  };
}

export async function getCustomerInvoices(
  conn: QBConnection,
  customerId: string,
  startDate?: string,
  endDate?: string,
) {
  const id = escapeQboString(customerId);
  let query =
    `SELECT Id, DocNumber, TxnDate, DueDate, TotalAmt, Balance, CustomerRef FROM Invoice ` +
    `WHERE CustomerRef = '${id}'`;
  if (startDate) query += ` AND TxnDate >= '${startDate}'`;
  if (endDate) query += ` AND TxnDate <= '${endDate}'`;
  query += ` MAXRESULTS 500`;
  return qbQuery(conn, query);
}

export async function getUnpaidInvoices(conn: QBConnection, minBalance = 0, maxResults = 100) {
  return qbQuery(
    conn,
    `SELECT Id, DocNumber, TxnDate, DueDate, TotalAmt, Balance, CustomerRef FROM Invoice ` +
      `WHERE Balance > '${minBalance}' MAXRESULTS ${Math.min(Math.max(maxResults, 1), 500)}`,
  );
}

export async function getUnpaidBills(conn: QBConnection, minBalance = 0, maxResults = 100) {
  return qbQuery(
    conn,
    `SELECT Id, DocNumber, TxnDate, DueDate, TotalAmt, Balance, VendorRef FROM Bill ` +
      `WHERE Balance > '${minBalance}' MAXRESULTS ${Math.min(Math.max(maxResults, 1), 500)}`,
  );
}

export async function listBudgets(conn: QBConnection) {
  return qbQuery(conn, "SELECT Id, Name, StartDate, EndDate, BudgetType, Active FROM Budget MAXRESULTS 50");
}

export async function getBudgetVsActual(
  conn: QBConnection,
  budgetId: string,
  startDate: string,
  endDate: string,
) {
  return report(conn, "reports/BudgetVsActuals", {
    budget: budgetId,
    start_date: startDate,
    end_date: endDate,
    rowaxis: "primary",
  });
}

function pickBalanceLikeFields(account: Record<string, unknown>): Record<string, unknown> {
  const extra: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(account)) {
    if (/balance|bank|feed|institution|available|cleared|fi/i.test(key)) {
      extra[key] = value;
    }
  }
  return extra;
}

/**
 * Bank/credit-card accounts with QBO Account.CurrentBalance (dashboard / account card)
 * alongside any extra balance-like fields Intuit returns on the entity.
 */
export async function getBankAccountBalances(conn: QBConnection) {
  const [banks, cards] = await Promise.all([
    qbQuery(conn, "SELECT * FROM Account WHERE AccountType = 'Bank' MAXRESULTS 100"),
    qbQuery(conn, "SELECT * FROM Account WHERE AccountType = 'Credit Card' MAXRESULTS 100").catch(
      () => ({ QueryResponse: { Account: [] } }),
    ),
  ]);
  const accounts = [
    ...(banks?.QueryResponse?.Account ?? []),
    ...(cards?.QueryResponse?.Account ?? []),
  ] as Array<Record<string, unknown>>;

  return {
    live_from_quickbooks: true,
    fetched_at_utc: new Date().toISOString(),
    how_to_read:
      "in_quickbooks_books comes from the Balance Sheet (register). " +
      "qbo_account_current_balance is Account.CurrentBalance — the figure QBO stores on the account " +
      "(often what the Banking/Dashboard card shows as the other / current number). " +
      "They diverge when For Review bank-feed items are not yet added to the register. " +
      "Intuit does not expose the raw bank-feed 'Bank balance' as its own API field.",
    accounts: accounts.map((a) => ({
      id: a.Id,
      name: a.Name,
      fully_qualified_name: a.FullyQualifiedName,
      account_type: a.AccountType,
      account_sub_type: a.AccountSubType,
      active: a.Active,
      online_banking_enabled: a.OnlineBankingEnabled ?? null,
      fi_name: a.FIName ?? null,
      qbo_account_current_balance: a.CurrentBalance ?? null,
      current_balance_with_subaccounts: a.CurrentBalanceWithSubAccounts ?? null,
      extra_balance_fields: pickBalanceLikeFields(a),
    })),
  };
}

export async function getCashPositionSnapshot(conn: QBConnection, asOfDate: string) {
  const [balanceSheet, ar, ap, bankAccounts] = await Promise.all([
    getBalanceSheet(conn, asOfDate),
    getARAging(conn, asOfDate),
    getAPAging(conn, asOfDate),
    getBankAccountBalances(conn),
  ]);

  return {
    as_of_date: asOfDate,
    live_from_quickbooks: true,
    fetched_at_utc: new Date().toISOString(),
    note:
      "For each bank (especially Chase): report BOTH " +
      "(1) Balance Sheet line = In QuickBooks / books / register (can be negative when For Review " +
      "feed items are not in the register) and " +
      "(2) qbo_account_current_balance = QBO account/dashboard current figure. " +
      "AR/AP aging are near-term estimates only.",
    balance_sheet: balanceSheet,
    bank_accounts: bankAccounts,
    ar_aging: ar,
    ap_aging: ap,
  };
}

export async function getChartOfAccounts(conn: QBConnection) {
  const result = await qbQuery(
    conn,
    "SELECT Id, Name, AccountType, AccountSubType, CurrentBalance, CurrentBalanceWithSubAccounts FROM Account MAXRESULTS 500",
  );
  return {
    ...result,
    warning:
      "For banks, CurrentBalance is the QBO account/dashboard current figure and can differ from the " +
      "Balance Sheet (In QuickBooks / register) when For Review transactions are outstanding. " +
      "Prefer get_cash_position_snapshot and show both numbers.",
  };
}
