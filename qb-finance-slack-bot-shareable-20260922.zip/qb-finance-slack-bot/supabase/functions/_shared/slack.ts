// Slack helpers: request signature verification (so randoms on the internet can't hit
// your webhook and make it call Claude/QuickBooks on your dime) and posting messages back.

const SLACK_SIGNING_SECRET = Deno.env.get("SLACK_SIGNING_SECRET")!;
const SLACK_BOT_TOKEN = Deno.env.get("SLACK_BOT_TOKEN")!;

const FIVE_MINUTES = 60 * 5;

function toHex(buffer: ArrayBuffer): string {
  return Array.from(new Uint8Array(buffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// Verifies the X-Slack-Signature header per Slack's signing secret spec:
// https://api.slack.com/authentication/verifying-requests-from-slack
export async function verifySlackSignature(
  rawBody: string,
  timestampHeader: string | null,
  signatureHeader: string | null,
): Promise<boolean> {
  if (!timestampHeader || !signatureHeader) return false;

  const timestamp = parseInt(timestampHeader, 10);
  if (Number.isNaN(timestamp) || Math.abs(Date.now() / 1000 - timestamp) > FIVE_MINUTES) {
    return false; // stale request — possible replay attack
  }

  const baseString = `v0:${timestampHeader}:${rawBody}`;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(SLACK_SIGNING_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(baseString));
  const computed = `v0=${toHex(signature)}`;

  // Constant-time-ish comparison
  if (computed.length !== signatureHeader.length) return false;
  let mismatch = 0;
  for (let i = 0; i < computed.length; i++) {
    mismatch |= computed.charCodeAt(i) ^ signatureHeader.charCodeAt(i);
  }
  return mismatch === 0;
}

/** Resolve a public channel ID from a name like "bbfinances-bot" or "#bbfinances-bot". */
export async function resolveChannelId(channelName: string): Promise<string> {
  const name = channelName.replace(/^#/, "");
  let cursor: string | undefined;

  do {
    const params = new URLSearchParams({
      types: "public_channel",
      limit: "200",
      exclude_archived: "true",
    });
    if (cursor) params.set("cursor", cursor);

    const res = await fetch(`https://slack.com/api/conversations.list?${params}`, {
      headers: { Authorization: `Bearer ${SLACK_BOT_TOKEN}` },
    });
    const body = await res.json();
    if (!body.ok) throw new Error(`Slack conversations.list failed: ${body.error}`);

    const match = (body.channels as Array<{ id: string; name: string; is_member?: boolean }>)
      .find((c) => c.name === name);
    if (match) {
      if (!match.is_member) {
        const join = await fetch("https://slack.com/api/conversations.join", {
          method: "POST",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Authorization: `Bearer ${SLACK_BOT_TOKEN}`,
          },
          body: JSON.stringify({ channel: match.id }),
        });
        const joinBody = await join.json();
        if (!joinBody.ok && joinBody.error !== "already_in_channel") {
          throw new Error(`Slack conversations.join failed: ${joinBody.error}`);
        }
      }
      return match.id;
    }

    cursor = body.response_metadata?.next_cursor || undefined;
  } while (cursor);

  throw new Error(`Slack channel not found: #${name} (invite the bot or check the name)`);
}

/**
 * Convert common Markdown to Slack mrkdwn so headings render bold.
 * Slack uses *bold* (not **bold**) and ignores # headers.
 * Leaves :emoji: shortcodes and Unicode emoji as-is.
 */
export function formatForSlack(text: string): string {
  let out = text.replace(/\r\n/g, "\n");
  out = out.replace(/^#{1,6}\s+(.+?)\s*$/gm, "*$1*");
  out = out.replace(/\*\*([^*]+)\*\*/g, "*$1*");
  out = out.replace(/__(.+?)__/g, "*$1*");
  return out;
}

export async function postMessage(
  channel: string,
  text: string,
  threadTs?: string,
): Promise<{ ok: boolean; ts: string; channel: string }> {
  const formatted = formatForSlack(text);
  try {
    return await slackApi("chat.postMessage", {
      channel,
      text: formatted,
      thread_ts: threadTs,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (threadTs && msg.includes("cannot_reply_to_message")) {
      return await slackApi("chat.postMessage", { channel, text: formatted });
    }
    throw err;
  }
}

const SLACK_TEXT_LIMIT = 3900;

export function chunkTextForSlack(text: string, maxLen = SLACK_TEXT_LIMIT): string[] {
  if (text.length <= maxLen) return [text];
  const chunks: string[] = [];
  let rest = text;
  while (rest.length > 0) {
    if (rest.length <= maxLen) {
      chunks.push(rest);
      break;
    }
    let splitAt = rest.lastIndexOf("\n", maxLen);
    if (splitAt < maxLen * 0.5) splitAt = maxLen;
    chunks.push(rest.slice(0, splitAt));
    rest = rest.slice(splitAt).trimStart();
  }
  return chunks;
}

async function slackApi(method: string, payload: Record<string, unknown>) {
  const res = await fetch(`https://slack.com/api/${method}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Authorization": `Bearer ${SLACK_BOT_TOKEN}`,
    },
    body: JSON.stringify(payload),
  });
  const body = await res.json();
  if (!body.ok) {
    throw new Error(`Slack ${method} failed: ${body.error}`);
  }
  return body;
}

export async function updateMessage(
  channel: string,
  messageTs: string,
  text: string,
  threadTs?: string,
): Promise<{ ok: boolean; ts: string; channel: string }> {
  const formatted = formatForSlack(text);
  try {
    return await slackApi("chat.update", {
      channel,
      ts: messageTs,
      text: formatted,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (threadTs && msg.includes("cannot_reply_to_message")) {
      return await slackApi("chat.update", { channel, ts: messageTs, text: formatted });
    }
    throw err;
  }
}

/** Post answer in Slack. Tries to replace the loading message; always posts if update fails. */
export async function deliverAnswer(
  channel: string,
  text: string,
  threadTs: string | undefined,
  loadingMessageTs?: string,
): Promise<void> {
  const chunks = chunkTextForSlack(formatForSlack(text));

  if (loadingMessageTs && chunks.length === 1) {
    try {
      await updateMessage(channel, loadingMessageTs, chunks[0], threadTs);
      return;
    } catch (err) {
      console.warn("chat.update failed, posting reply instead:", err);
    }
  }

  if (loadingMessageTs && chunks.length > 1) {
    try {
      await updateMessage(
        channel,
        loadingMessageTs,
        `${chunks[0]}\n\n(continued below…)`,
        threadTs,
      );
      for (let i = 1; i < chunks.length; i++) {
        await postMessage(channel, chunks[i], threadTs);
      }
      return;
    } catch (err) {
      console.warn("chat.update failed, posting reply instead:", err);
    }
  }

  for (const chunk of chunks) {
    await postMessage(channel, chunk, threadTs);
  }
}
