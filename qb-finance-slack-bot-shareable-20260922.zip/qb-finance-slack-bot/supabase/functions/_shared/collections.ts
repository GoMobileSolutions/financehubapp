// Collections / AR digest: snapshot persistence, week-over-week diffs, Slack formatting.

import type { SupabaseClient } from "npm:@supabase/supabase-js@2";
import type { ARAgingDetailResult, ARAgingInvoiceRow, AgingBucket } from "./quickbooks.ts";
import {
  getARAgingDetail,
  getARAgingDetailFromReport,
  getPaymentsInDateRange,
  mapInvoiceDocNumbersToIds,
} from "./quickbooks.ts";
import type { QBConnection } from "./types.ts";
import { getPTDateTime, type PTDateTime } from "./digest.ts";

export interface ARSnapshotRow {
  snapshot_date: string;
  customer_id: string;
  customer_name: string;
  invoice_id: string;
  invoice_number: string;
  balance: number;
  days_overdue: number;
  product_service: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  original_amount: number | null;
  aging_bucket: string | null;
}

export interface RecoveredInvoice {
  customer_name: string;
  invoice_number: string;
  invoice_id: string;
  amount_recovered: number;
  product_service: string | null;
  /** true = invoice cleared entirely; false = partial paydown still open */
  fully_cleared: boolean;
}

export interface NewOutstandingInvoice {
  customer_name: string;
  invoice_number: string;
  invoice_id: string;
  balance: number;
  original_amount: number;
  days_overdue: number;
  due_date: string;
  invoice_date: string;
  product_service: string;
  contact_email: string | null;
  contact_phone: string | null;
  aging_bucket: string;
}

export interface StillOutstandingInvoice {
  customer_name: string;
  invoice_number: string;
  invoice_id: string;
  balance: number;
  original_amount: number;
  days_overdue: number;
  days_overdue_delta: number;
  due_date: string;
  invoice_date: string;
  product_service: string;
  contact_email: string | null;
  contact_phone: string | null;
  aging_bucket: string;
}

export interface CollectionsWeekDiff {
  previous_snapshot_date: string | null;
  total_recovered: number;
  payments_recovered_count: number;
  total_still_outstanding: number;
  new_outstanding_count: number;
  new_outstanding_revenue: number;
  new_outstanding: NewOutstandingInvoice[];
  recovered: RecoveredInvoice[];
  still_outstanding: StillOutstandingInvoice[];
  /** Invoices that crossed into 91+ this week */
  newly_critical_count: number;
  newly_critical_revenue: number;
  /** Unique customers with open AR */
  unique_customers: number;
}

export interface WeekPaymentsSummary {
  start_date: string;
  end_date: string;
  payment_count: number;
  total_collected: number;
  top_payments: Array<{ customer_name: string; amount: number; date: string }>;
}

export interface CollectionsDigestPayload {
  as_of_date: string;
  week_label: string;
  current: ARAgingDetailResult;
  previous_total: number | null;
  percent_change: number | null;
  cumulative_recovered: number;
  diff: CollectionsWeekDiff;
  week_payments: WeekPaymentsSummary | null;
  /** Optional banner, e.g. historical backfill note */
  banner?: string;
}

const BUCKET_ORDER: AgingBucket[] = ["current", "1-30", "31-60", "61-90", "91+"];

/** Friday 6 PM Pacific — same window as the weekly finance digest. */
export function isCollectionsDigestDue(pt: PTDateTime = getPTDateTime()): boolean {
  return pt.hour === 18 && pt.weekday === 5;
}

function money(n: number): string {
  const abs = Math.abs(n);
  const formatted = abs.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  });
  return n < 0 ? `-${formatted}` : formatted;
}

export async function loadPreviousSnapshot(
  supabase: SupabaseClient,
  beforeDate: string,
): Promise<{ snapshot_date: string; rows: ARSnapshotRow[] } | null> {
  const { data: dates, error: dateErr } = await supabase
    .from("ar_snapshots")
    .select("snapshot_date")
    .lt("snapshot_date", beforeDate)
    .order("snapshot_date", { ascending: false })
    .limit(1);
  if (dateErr) throw new Error(`ar_snapshots date lookup failed: ${dateErr.message}`);
  const prevDate = dates?.[0]?.snapshot_date as string | undefined;
  if (!prevDate) return null;

  const { data, error } = await supabase
    .from("ar_snapshots")
    .select("*")
    .eq("snapshot_date", prevDate);
  if (error) throw new Error(`ar_snapshots load failed: ${error.message}`);
  return { snapshot_date: prevDate, rows: (data ?? []) as ARSnapshotRow[] };
}

export async function loadSnapshotForDate(
  supabase: SupabaseClient,
  snapshotDate: string,
): Promise<{ snapshot_date: string; rows: ARSnapshotRow[] } | null> {
  const { data, error } = await supabase
    .from("ar_snapshots")
    .select("*")
    .eq("snapshot_date", snapshotDate);
  if (error) throw new Error(`ar_snapshots load failed: ${error.message}`);
  if (!data || data.length === 0) return null;
  return { snapshot_date: snapshotDate, rows: data as ARSnapshotRow[] };
}

function formatShortDate(ymd: string): string {
  const [y, m, d] = ymd.split("-").map((n) => parseInt(n, 10));
  const dt = new Date(Date.UTC(y, m - 1, d));
  return new Intl.DateTimeFormat("en-US", {
    timeZone: "UTC",
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(dt);
}

export function weekLabelForDigest(
  asOfDate: string,
  previousSnapshotDate: string | null,
): string {
  if (!previousSnapshotDate) return formatShortDate(asOfDate);
  return `${formatShortDate(previousSnapshotDate)}–${formatShortDate(asOfDate)}`;
}

export function diffSnapshots(
  current: ARAgingInvoiceRow[],
  previous: ARSnapshotRow[] | null,
  previousSnapshotDate: string | null,
): CollectionsWeekDiff {
  const mapNew = (r: ARAgingInvoiceRow): NewOutstandingInvoice => ({
    customer_name: r.customer_name,
    invoice_number: r.invoice_number,
    invoice_id: r.invoice_id,
    balance: r.balance,
    original_amount: r.original_amount,
    days_overdue: r.days_overdue,
    due_date: r.due_date,
    invoice_date: r.invoice_date,
    product_service: r.product_service,
    contact_email: r.contact_email,
    contact_phone: r.contact_phone,
    aging_bucket: r.aging_bucket,
  });

  const mapStill = (
    r: ARAgingInvoiceRow,
    daysDelta: number,
  ): StillOutstandingInvoice => ({
    customer_name: r.customer_name,
    invoice_number: r.invoice_number,
    invoice_id: r.invoice_id,
    balance: r.balance,
    original_amount: r.original_amount,
    days_overdue: r.days_overdue,
    days_overdue_delta: daysDelta,
    due_date: r.due_date,
    invoice_date: r.invoice_date,
    product_service: r.product_service,
    contact_email: r.contact_email,
    contact_phone: r.contact_phone,
    aging_bucket: r.aging_bucket,
  });

  if (!previous || previous.length === 0) {
    const still = current.map((r) => mapStill(r, 0));
    still.sort((a, b) => b.days_overdue - a.days_overdue || b.balance - a.balance);
    const critical = still.filter((r) => r.days_overdue >= 91);
    return {
      previous_snapshot_date: previousSnapshotDate,
      total_recovered: 0,
      payments_recovered_count: 0,
      total_still_outstanding: current.reduce((s, r) => s + r.balance, 0),
      new_outstanding_count: current.length,
      new_outstanding_revenue: current.reduce((s, r) => s + r.balance, 0),
      new_outstanding: current.map(mapNew).sort((a, b) => b.balance - a.balance),
      recovered: [],
      still_outstanding: still,
      newly_critical_count: critical.length,
      newly_critical_revenue: critical.reduce((s, r) => s + r.balance, 0),
      unique_customers: new Set(current.map((r) => r.customer_id || r.customer_name)).size,
    };
  }

  const prevByInvoice = new Map(previous.map((r) => [r.invoice_id, r]));
  const currByInvoice = new Map(current.map((r) => [r.invoice_id, r]));

  const recovered: RecoveredInvoice[] = [];
  for (const prev of previous) {
    if (!currByInvoice.has(prev.invoice_id)) {
      recovered.push({
        customer_name: prev.customer_name,
        invoice_number: prev.invoice_number,
        invoice_id: prev.invoice_id,
        amount_recovered: Number(prev.balance),
        product_service: prev.product_service,
        fully_cleared: true,
      });
    } else {
      const curr = currByInvoice.get(prev.invoice_id)!;
      const paidDown = Number(prev.balance) - curr.balance;
      if (paidDown > 0.009) {
        recovered.push({
          customer_name: curr.customer_name,
          invoice_number: curr.invoice_number,
          invoice_id: curr.invoice_id,
          amount_recovered: paidDown,
          product_service: curr.product_service,
          fully_cleared: false,
        });
      }
    }
  }

  const new_outstanding: NewOutstandingInvoice[] = current
    .filter((r) => !prevByInvoice.has(r.invoice_id))
    .map(mapNew)
    .sort((a, b) => b.balance - a.balance);

  const still_outstanding: StillOutstandingInvoice[] = current.map((r) => {
    const prev = prevByInvoice.get(r.invoice_id);
    return mapStill(r, prev ? r.days_overdue - Number(prev.days_overdue) : 0);
  });
  still_outstanding.sort((a, b) => b.days_overdue - a.days_overdue || b.balance - a.balance);

  let newly_critical_count = 0;
  let newly_critical_revenue = 0;
  for (const r of still_outstanding) {
    if (r.days_overdue < 91) continue;
    const prev = prevByInvoice.get(r.invoice_id);
    const wasCritical = prev ? Number(prev.days_overdue) >= 91 : false;
    if (!wasCritical) {
      newly_critical_count += 1;
      newly_critical_revenue += r.balance;
    }
  }

  return {
    previous_snapshot_date: previousSnapshotDate,
    total_recovered: recovered.reduce((s, r) => s + r.amount_recovered, 0),
    payments_recovered_count: recovered.length,
    total_still_outstanding: current.reduce((s, r) => s + r.balance, 0),
    new_outstanding_count: new_outstanding.length,
    new_outstanding_revenue: new_outstanding.reduce((s, r) => s + r.balance, 0),
    new_outstanding,
    recovered: recovered.sort((a, b) => b.amount_recovered - a.amount_recovered),
    still_outstanding,
    newly_critical_count,
    newly_critical_revenue,
    unique_customers: new Set(current.map((r) => r.customer_id || r.customer_name)).size,
  };
}

/** Sum recovered across every consecutive snapshot pair up through live current. */
export async function computeCumulativeRecovered(
  supabase: SupabaseClient,
  asOfDate: string,
  latestCurrent: ARAgingInvoiceRow[],
): Promise<number> {
  const { data, error } = await supabase
    .from("ar_snapshots")
    .select("snapshot_date")
    .lt("snapshot_date", asOfDate)
    .order("snapshot_date", { ascending: true });
  if (error) throw new Error(`ar_snapshots cumulative lookup failed: ${error.message}`);

  const dates = [...new Set((data ?? []).map((r) => r.snapshot_date as string))];
  if (dates.length === 0) return 0;

  const loadRows = async (date: string): Promise<ARSnapshotRow[]> => {
    const { data: rows, error: loadErr } = await supabase
      .from("ar_snapshots")
      .select("*")
      .eq("snapshot_date", date);
    if (loadErr) throw new Error(`ar_snapshots load failed: ${loadErr.message}`);
    return (rows ?? []) as ARSnapshotRow[];
  };

  const toInvoiceRows = (rows: ARSnapshotRow[]): ARAgingInvoiceRow[] =>
    rows.map((r) => ({
      invoice_id: r.invoice_id,
      invoice_number: r.invoice_number,
      invoice_date: "",
      due_date: "",
      days_overdue: Number(r.days_overdue),
      aging_bucket: (r.aging_bucket as AgingBucket) ?? "current",
      balance: Number(r.balance),
      original_amount: Number(r.original_amount ?? r.balance),
      customer_id: r.customer_id,
      customer_name: r.customer_name,
      contact_email: r.contact_email,
      contact_phone: r.contact_phone,
      product_service: r.product_service ?? "",
      line_items: [],
    }));

  let total = 0;
  for (let i = 0; i < dates.length - 1; i++) {
    const prev = await loadRows(dates[i]);
    const next = await loadRows(dates[i + 1]);
    total += diffSnapshots(toInvoiceRows(next), prev, dates[i]).total_recovered;
  }

  const lastPrev = await loadRows(dates[dates.length - 1]);
  total += diffSnapshots(latestCurrent, lastPrev, dates[dates.length - 1]).total_recovered;
  return total;
}

export async function writeARSnapshot(
  supabase: SupabaseClient,
  snapshotDate: string,
  invoices: ARAgingInvoiceRow[],
): Promise<void> {
  // Replace any same-day rows so force= re-runs stay idempotent.
  const { error: delErr } = await supabase
    .from("ar_snapshots")
    .delete()
    .eq("snapshot_date", snapshotDate);
  if (delErr) throw new Error(`ar_snapshots delete failed: ${delErr.message}`);

  if (invoices.length === 0) return;

  const rows = invoices.map((inv) => ({
    snapshot_date: snapshotDate,
    customer_id: inv.customer_id,
    customer_name: inv.customer_name,
    invoice_id: inv.invoice_id,
    invoice_number: inv.invoice_number,
    balance: inv.balance,
    days_overdue: inv.days_overdue,
    product_service: inv.product_service,
    contact_email: inv.contact_email,
    contact_phone: inv.contact_phone,
    original_amount: inv.original_amount,
    aging_bucket: inv.aging_bucket,
  }));

  const chunkSize = 200;
  for (let i = 0; i < rows.length; i += chunkSize) {
    const chunk = rows.slice(i, i + chunkSize);
    const { error } = await supabase.from("ar_snapshots").insert(chunk);
    if (error) throw new Error(`ar_snapshots insert failed: ${error.message}`);
  }
}

export async function buildCollectionsDigest(
  supabase: SupabaseClient,
  conn: QBConnection,
  asOfDate?: string,
): Promise<CollectionsDigestPayload> {
  const current = await getARAgingDetail(conn, asOfDate);
  let previous = await loadPreviousSnapshot(supabase, current.as_of_date);
  // Same-day force re-run: use today's existing rows as previous so the Revatto-style
  // week stats render (instead of forever-baseline until next calendar week).
  if (!previous) {
    previous = await loadSnapshotForDate(supabase, current.as_of_date);
  }
  const previousTotal = previous
    ? previous.rows.reduce((s, r) => s + Number(r.balance), 0)
    : null;
  const percentChange =
    previousTotal !== null && previousTotal > 0
      ? ((current.total_outstanding - previousTotal) / previousTotal) * 100
      : null;

  const paymentStart =
    previous && previous.snapshot_date !== current.as_of_date
      ? previous.snapshot_date
      : (() => {
          // Default lookback: 7 days before as-of
          const [y, m, d] = current.as_of_date.split("-").map((n) => parseInt(n, 10));
          const dt = new Date(Date.UTC(y, m - 1, d - 7));
          return dt.toISOString().slice(0, 10);
        })();

  const [diff, cumulative_recovered, paymentsRaw] = await Promise.all([
    Promise.resolve(
      diffSnapshots(
        current.invoices,
        previous?.rows ?? null,
        previous?.snapshot_date ?? null,
      ),
    ),
    computeCumulativeRecovered(supabase, current.as_of_date, current.invoices),
    getPaymentsInDateRange(conn, paymentStart, current.as_of_date).catch(() => null),
  ]);

  await writeARSnapshot(supabase, current.as_of_date, current.invoices);

  const week_payments: WeekPaymentsSummary | null = paymentsRaw
    ? {
        start_date: paymentsRaw.start_date,
        end_date: paymentsRaw.end_date,
        payment_count: paymentsRaw.payment_count,
        total_collected: paymentsRaw.total_collected,
        top_payments: [...paymentsRaw.payments]
          .sort((a, b) => b.amount - a.amount)
          .slice(0, 8)
          .map((p) => ({
            customer_name: p.customer_name || "Unknown",
            amount: p.amount,
            date: p.date,
          })),
      }
    : null;

  return {
    as_of_date: current.as_of_date,
    week_label: weekLabelForDigest(
      current.as_of_date,
      previous && previous.snapshot_date !== current.as_of_date
        ? previous.snapshot_date
        : null,
    ),
    current,
    previous_total: previousTotal,
    percent_change: percentChange,
    cumulative_recovered,
    diff,
    week_payments,
  };
}

function addDaysYmd(ymd: string, delta: number): string {
  const [y, m, d] = ymd.split("-").map((n) => parseInt(n, 10));
  const dt = new Date(Date.UTC(y, m - 1, d + delta));
  return dt.toISOString().slice(0, 10);
}

/**
 * Backfill recovery stats: compare live open AR vs QBO AgedReceivableDetail
 * as of (today - compareDays). Does not require stored ar_snapshots history.
 */
export async function buildHistoricalCollectionsCompare(
  conn: QBConnection,
  compareDays = 14,
  asOfDate?: string,
): Promise<CollectionsDigestPayload> {
  const current = await getARAgingDetail(conn, asOfDate);
  const pastDate = addDaysYmd(current.as_of_date, -Math.abs(compareDays));

  const [pastReport, docMap, paymentsRaw] = await Promise.all([
    getARAgingDetailFromReport(conn, pastDate),
    mapInvoiceDocNumbersToIds(conn),
    getPaymentsInDateRange(conn, pastDate, current.as_of_date).catch(() => null),
  ]);

  // Align historical rows onto live Invoice Ids via DocNumber.
  const pastRows: ARAgingInvoiceRow[] = pastReport.invoices.map((r) => {
    const mappedId = r.invoice_number ? docMap.get(r.invoice_number) : undefined;
    return {
      ...r,
      invoice_id: mappedId || r.invoice_id || r.invoice_number,
    };
  });

  const pastAsSnapshot: ARSnapshotRow[] = pastRows.map((r) => ({
    snapshot_date: pastDate,
    customer_id: r.customer_id,
    customer_name: r.customer_name,
    invoice_id: r.invoice_id,
    invoice_number: r.invoice_number,
    balance: r.balance,
    days_overdue: r.days_overdue,
    product_service: r.product_service,
    contact_email: r.contact_email,
    contact_phone: r.contact_phone,
    original_amount: r.original_amount,
    aging_bucket: r.aging_bucket,
  }));

  const previousTotal = pastAsSnapshot.reduce((s, r) => s + Number(r.balance), 0);
  const percentChange =
    previousTotal > 0
      ? ((current.total_outstanding - previousTotal) / previousTotal) * 100
      : null;

  const diff = diffSnapshots(current.invoices, pastAsSnapshot, pastDate);

  const week_payments: WeekPaymentsSummary | null = paymentsRaw
    ? {
        start_date: paymentsRaw.start_date,
        end_date: paymentsRaw.end_date,
        payment_count: paymentsRaw.payment_count,
        total_collected: paymentsRaw.total_collected,
        top_payments: [...paymentsRaw.payments]
          .sort((a, b) => b.amount - a.amount)
          .slice(0, 8)
          .map((p) => ({
            customer_name: p.customer_name || "Unknown",
            amount: p.amount,
            date: p.date,
          })),
      }
    : null;

  return {
    as_of_date: current.as_of_date,
    week_label: weekLabelForDigest(current.as_of_date, pastDate),
    current,
    previous_total: previousTotal,
    percent_change: percentChange,
    cumulative_recovered: diff.total_recovered,
    diff,
    week_payments,
    banner:
      `_Historical compare:_ open AR today vs QuickBooks AR Aging Detail as of *${pastDate}* (${compareDays} days back). Not using stored snapshots.`,
  };
}

/** Full collections context for live Q&A — one parallel fetch, no month loops. */
export async function getCollectionsLiveSnapshot(
  supabase: SupabaseClient,
  conn: QBConnection,
  asOfDate?: string,
): Promise<Record<string, unknown>> {
  const current = await getARAgingDetail(conn, asOfDate);
  const previous = await loadPreviousSnapshot(supabase, current.as_of_date);
  const previousTotal = previous
    ? previous.rows.reduce((s, r) => s + Number(r.balance), 0)
    : null;
  const diff = diffSnapshots(
    current.invoices,
    previous?.rows ?? null,
    previous?.snapshot_date ?? null,
  );

  return {
    live_from_quickbooks: true,
    fetched_at_utc: current.fetched_at_utc,
    as_of_date: current.as_of_date,
    total_outstanding: current.total_outstanding,
    previous_snapshot_date: diff.previous_snapshot_date,
    previous_total_outstanding: previousTotal,
    percent_change_vs_last_snapshot:
      previousTotal !== null && previousTotal > 0
        ? ((current.total_outstanding - previousTotal) / previousTotal) * 100
        : null,
    buckets: current.buckets,
    new_outstanding_count: diff.new_outstanding_count,
    new_outstanding_revenue: diff.new_outstanding_revenue,
    total_recovered_since_last_snapshot: diff.total_recovered,
    payments_recovered_count: diff.payments_recovered_count,
    recovered: diff.recovered.slice(0, 50),
    still_outstanding: diff.still_outstanding.slice(0, 80),
    invoices: current.invoices.slice(0, 80),
    note:
      "Fetched once: open invoices + customer contacts in parallel. " +
      "Do not invent why a customer is late. Contact info is for humans to act on — no outbound email.",
  };
}

/**
 * Revatto-style weekly recovery digest for Slack.
 * Maps AR snapshot diffs → new outstanding / recovered / in progress / critically overdue.
 */
export function formatCollectionsDigestSlack(payload: CollectionsDigestPayload): string {
  const {
    current,
    diff,
    week_label,
    cumulative_recovered,
    previous_total,
    percent_change,
    week_payments,
    banner,
  } = payload;
  const lines: string[] = [];

  const isBaseline = !diff.previous_snapshot_date;
  lines.push(`Hey <!channel>`);
  lines.push(
    isBaseline
      ? `Here's your latest *Collections Report* as of ${week_label} _(baseline snapshot — week-over-week stats start next run)_`
      : `Here's your latest *Collections Report* for ${week_label}`,
  );
  if (banner) lines.push(banner);
  lines.push("");

  const fullyCleared = diff.recovered.filter((r) => r.fully_cleared);
  const partialPaydowns = diff.recovered.filter((r) => !r.fully_cleared);
  const fullyClearedAmt = fullyCleared.reduce((s, r) => s + r.amount_recovered, 0);
  const partialAmt = partialPaydowns.reduce((s, r) => s + r.amount_recovered, 0);
  const openCount = diff.still_outstanding.length;
  const noWeekChange =
    diff.new_outstanding_count === 0 &&
    diff.payments_recovered_count === 0 &&
    diff.total_recovered === 0;

  // Lead with what's open *right now* so week-over-week zeros aren't confusing.
  lines.push(
    `*Open AR right now:* ${money(diff.total_still_outstanding)} across *${openCount}* invoice${openCount === 1 ? "" : "s"} / *${diff.unique_customers}* customer${diff.unique_customers === 1 ? "" : "s"}`,
  );
  lines.push("");

  lines.push("*RECOVERY & AR STATS* _(changes vs last snapshot)_:");
  lines.push(`- New open invoices this week: ${diff.new_outstanding_count}`);
  lines.push(`- New outstanding revenue totaled ${money(diff.new_outstanding_revenue)}`);
  lines.push(`- Invoices recovered this week: ${diff.payments_recovered_count}`);
  lines.push(`- Revenue recovered: ${money(diff.total_recovered)}`);
  if (diff.payments_recovered_count > 0) {
    lines.push(
      `  · Fully paid: ${fullyCleared.length} (${money(fullyClearedAmt)}) · Partial paydowns: ${partialPaydowns.length} (${money(partialAmt)})`,
    );
  }
  if (week_payments) {
    lines.push(
      `- Cash collected (QB payments ${week_payments.start_date}→${week_payments.end_date}): ${week_payments.payment_count} payment${week_payments.payment_count === 1 ? "" : "s"} · ${money(week_payments.total_collected)}`,
    );
  }
  if (noWeekChange) {
    lines.push(
      `_No AR change since last snapshot — the ${openCount} invoice${openCount === 1 ? "" : "s"} above are the same ones still outstanding (not “zero AR”)._`,
    );
  }
  lines.push("");

  lines.push(
    `We currently have *${openCount}* in progress across *${diff.unique_customers}* customer${diff.unique_customers === 1 ? "" : "s"}, with *${money(diff.total_still_outstanding)}* in potential recoveries.`,
  );

  const critical = diff.still_outstanding.filter((r) => r.days_overdue >= 91);
  const criticalCustomers = new Set(critical.map((r) => r.customer_name));
  const criticalTotal = critical.reduce((s, r) => s + r.balance, 0);
  lines.push(
    `We're also watching *${criticalCustomers.size}* customer${criticalCustomers.size === 1 ? "" : "s"} at *91+ days overdue* representing *${money(criticalTotal)}* in potential revenue` +
      (diff.newly_critical_count > 0
        ? ` _(${diff.newly_critical_count} newly entered 91+ this week · ${money(diff.newly_critical_revenue)})_`
        : "") +
      `.`,
  );

  const mid = diff.still_outstanding.filter((r) => r.days_overdue >= 61 && r.days_overdue <= 90);
  const midCustomers = new Set(mid.map((r) => r.customer_name));
  const midTotal = mid.reduce((s, r) => s + r.balance, 0);
  if (mid.length > 0) {
    lines.push(
      `Priority follow-up (61–90 days): *${midCustomers.size}* customer${midCustomers.size === 1 ? "" : "s"} · *${money(midTotal)}*.`,
    );
  }
  lines.push("");

  lines.push("*AR HEALTH:*");
  if (previous_total !== null && percent_change !== null) {
    const direction = current.total_outstanding - previous_total;
    lines.push(
      `- Total AR: ${money(current.total_outstanding)} (${direction >= 0 ? "+" : ""}${money(direction)} / ${percent_change >= 0 ? "+" : ""}${percent_change.toFixed(1)}% vs last week)`,
    );
  } else {
    lines.push(`- Total AR: ${money(current.total_outstanding)}`);
  }

  const overdue = diff.still_outstanding.filter((r) => r.days_overdue > 0);
  const overdueAmt = overdue.reduce((s, r) => s + r.balance, 0);
  const currentNotDue = diff.still_outstanding.filter((r) => r.days_overdue <= 0);
  const currentNotDueAmt = currentNotDue.reduce((s, r) => s + r.balance, 0);
  const avgDays =
    overdue.length > 0
      ? Math.round(overdue.reduce((s, r) => s + r.days_overdue, 0) / overdue.length)
      : 0;
  const sortedDays = [...overdue].map((r) => r.days_overdue).sort((a, b) => a - b);
  const medianDays =
    sortedDays.length === 0
      ? 0
      : sortedDays.length % 2 === 1
      ? sortedDays[(sortedDays.length - 1) / 2]
      : Math.round(
          (sortedDays[sortedDays.length / 2 - 1] + sortedDays[sortedDays.length / 2]) / 2,
        );
  lines.push(
    `- Past due: ${overdue.length} invoice${overdue.length === 1 ? "" : "s"} · ${money(overdueAmt)} · avg ${avgDays}d / median ${medianDays}d overdue`,
  );
  lines.push(
    `- Not yet due (current): ${currentNotDue.length} · ${money(currentNotDueAmt)}`,
  );

  const avgBalance =
    openCount > 0 ? Math.round(diff.total_still_outstanding / openCount) : 0;
  const largest = diff.still_outstanding[0];
  if (largest) {
    lines.push(
      `- Avg open balance: ${money(avgBalance)} · Largest: ${largest.customer_name} ${money(largest.balance)} (${largest.days_overdue}d, #${largest.invoice_number || largest.invoice_id})`,
    );
  }

  const worsened = diff.still_outstanding.filter((r) => r.days_overdue_delta > 0);
  const worsenedAmt = worsened.reduce((s, r) => s + r.balance, 0);
  lines.push(
    `- Aging worsened this week: ${worsened.length} invoice${worsened.length === 1 ? "" : "s"} still open (${money(worsenedAmt)})`,
  );

  const withEmail = diff.still_outstanding.filter((r) => r.contact_email).length;
  const withPhone = diff.still_outstanding.filter((r) => r.contact_phone).length;
  const missingContact = diff.still_outstanding.filter(
    (r) => !r.contact_email && !r.contact_phone,
  );
  lines.push(
    `- Contact coverage: ${withEmail}/${openCount} email · ${withPhone}/${openCount} phone · ${missingContact.length} missing both`,
  );

  const byCustomer = new Map<string, number>();
  for (const r of diff.still_outstanding) {
    byCustomer.set(r.customer_name, (byCustomer.get(r.customer_name) ?? 0) + r.balance);
  }
  const topCustomers = [...byCustomer.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  if (topCustomers.length > 0 && diff.total_still_outstanding > 0) {
    const topSum = topCustomers.slice(0, 3).reduce((s, [, amt]) => s + amt, 0);
    const topPct = Math.round((topSum / diff.total_still_outstanding) * 100);
    lines.push(
      `- Top customers by AR (${topPct}% in top 3):`,
    );
    for (const [name, amt] of topCustomers) {
      const share = Math.round((amt / diff.total_still_outstanding) * 100);
      lines.push(`  · ${name} — ${money(amt)} (${share}%)`);
    }
  }

  // Product/service concentration
  const byProduct = new Map<string, number>();
  for (const r of diff.still_outstanding) {
    const key = r.product_service?.split(",")[0]?.trim() || "(no product/service)";
    byProduct.set(key, (byProduct.get(key) ?? 0) + r.balance);
  }
  const topProducts = [...byProduct.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  if (topProducts.length > 0) {
    lines.push(`- Top products/services in open AR:`);
    for (const [name, amt] of topProducts) {
      lines.push(`  · ${name} — ${money(amt)}`);
    }
  }
  lines.push("");

  lines.push(
    `Since we started tracking collections snapshots, you've recovered *${money(cumulative_recovered)}* in revenue!`,
  );
  lines.push("");

  lines.push("*Aging snapshot*");
  for (const key of BUCKET_ORDER) {
    const b = current.buckets[key];
    if (b.count === 0 && b.amount === 0) continue;
    lines.push(`• *${key}:* ${money(b.amount)} (${b.percent}% · ${b.count})`);
  }
  lines.push("");

  if (week_payments && week_payments.top_payments.length > 0) {
    lines.push("*Cash collected this period*");
    for (const p of week_payments.top_payments) {
      lines.push(`• ${p.customer_name} — ${money(p.amount)} (${p.date})`);
    }
    if (week_payments.payment_count > week_payments.top_payments.length) {
      lines.push(
        `• _…and ${week_payments.payment_count - week_payments.top_payments.length} more payments_`,
      );
    }
    lines.push("");
  }

  if (diff.new_outstanding.length > 0) {
    lines.push("*New open invoices this week*");
    for (const r of diff.new_outstanding.slice(0, 15)) {
      const inv = r.invoice_number ? `#${r.invoice_number}` : r.invoice_id;
      const contact = [r.contact_email, r.contact_phone].filter(Boolean).join(" · ") ||
        "_no contact on file_";
      lines.push(
        `• ${r.customer_name} — ${money(r.balance)} (of ${money(r.original_amount)}), ${r.days_overdue}d overdue, due ${r.due_date}, ${inv}, ${r.product_service}`,
      );
      lines.push(`  ${contact}`);
    }
    if (diff.new_outstanding.length > 15) {
      lines.push(`• _…and ${diff.new_outstanding.length - 15} more_`);
    }
    lines.push("");
  }

  if (diff.recovered.length > 0) {
    lines.push("*Recovered this week*");
    for (const r of diff.recovered.slice(0, 15)) {
      const inv = r.invoice_number ? ` #${r.invoice_number}` : "";
      const tag = r.fully_cleared ? "paid in full" : "partial";
      lines.push(`• ${r.customer_name}${inv} — ${money(r.amount_recovered)} _(${tag})_`);
    }
    if (diff.recovered.length > 15) {
      lines.push(`• _…and ${diff.recovered.length - 15} more_`);
    }
    lines.push("");
  }

  if (diff.still_outstanding.length > 0) {
    lines.push("*Still outstanding (worst first)*");
    for (const r of diff.still_outstanding.slice(0, 20)) {
      const inv = r.invoice_number ? `#${r.invoice_number}` : r.invoice_id;
      const delta =
        r.days_overdue_delta > 0 ? ` (+${r.days_overdue_delta}d)` : "";
      const contact = [r.contact_email, r.contact_phone].filter(Boolean).join(" · ") ||
        "_no contact on file_";
      lines.push(
        `• ${r.customer_name} — ${money(r.balance)} (of ${money(r.original_amount)}), ${r.days_overdue}d overdue${delta}, due ${r.due_date}, ${inv}, ${r.aging_bucket}, ${r.product_service}`,
      );
      lines.push(`  ${contact}`);
    }
    if (diff.still_outstanding.length > 20) {
      lines.push(`• _…and ${diff.still_outstanding.length - 20} more_`);
    }
    lines.push("");
  }

  if (missingContact.length > 0) {
    lines.push("*Missing contact info*");
    for (const r of missingContact.slice(0, 10)) {
      const inv = r.invoice_number ? `#${r.invoice_number}` : r.invoice_id;
      lines.push(`• ${r.customer_name} — ${money(r.balance)}, ${inv}`);
    }
    if (missingContact.length > 10) {
      lines.push(`• _…and ${missingContact.length - 10} more_`);
    }
    lines.push("");
  }

  lines.push(
    "_Ask me in this channel for contact info or a customer deep-dive. Reporting only — no outbound outreach._",
  );
  lines.push("");
  lines.push("- The Collections Agent");

  return lines.join("\n");
}
