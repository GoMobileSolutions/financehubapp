-- Deduplicate Slack Events API deliveries (retries + dual app_mention/message.channels).

create table if not exists slack_processed_events (
  event_id text primary key,
  created_at timestamptz not null default now()
);

create index if not exists slack_processed_events_created_at_idx
  on slack_processed_events (created_at desc);

alter table slack_processed_events enable row level security;
