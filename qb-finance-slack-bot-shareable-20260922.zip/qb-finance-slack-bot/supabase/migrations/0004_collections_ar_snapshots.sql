-- Collections agent: weekly AR snapshots for week-over-week recovery diffs,
-- allow digest_runs.digest_type = 'collections', and hourly cron → collections-digest.

create table if not exists ar_snapshots (
  id uuid primary key default gen_random_uuid(),
  snapshot_date date not null,
  customer_id text not null,
  customer_name text not null,
  invoice_id text not null,
  invoice_number text not null default '',
  balance numeric not null,
  days_overdue integer not null default 0,
  product_service text,
  contact_email text,
  contact_phone text,
  original_amount numeric,
  aging_bucket text,
  created_at timestamptz not null default now(),
  unique (snapshot_date, invoice_id)
);

create index if not exists ar_snapshots_snapshot_date_idx on ar_snapshots (snapshot_date desc);
create index if not exists ar_snapshots_customer_idx on ar_snapshots (customer_id, snapshot_date desc);

alter table ar_snapshots enable row level security;
-- No policies = service_role only (matches qb_connections / query_log).

-- Expand digest_runs to include collections weekly digests.
alter table digest_runs drop constraint if exists digest_runs_digest_type_check;
alter table digest_runs
  add constraint digest_runs_digest_type_check
  check (digest_type in ('daily', 'weekly', 'monthly', 'collections'));

-- Hourly trigger: collections-digest self-gates to Friday 6 PM Pacific.
do $$
declare
  job_id bigint;
begin
  select jobid into job_id from cron.job where jobname = 'bb-finances-hourly-collections';
  if job_id is not null then
    perform cron.unschedule(job_id);
  end if;
end $$;

select cron.schedule(
  'bb-finances-hourly-collections',
  '0 * * * *',
  $$
  select net.http_post(
    url := coalesce(
      (select value from public.app_config where key = 'collections_digest_url'),
      ''
    ),
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-cron-secret', coalesce((select value from public.app_config where key = 'cron_secret'), '')
    ),
    body := '{}'::jsonb
  ) as request_id;
  $$
);
