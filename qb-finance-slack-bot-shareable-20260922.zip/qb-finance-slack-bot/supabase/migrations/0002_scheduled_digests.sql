-- Scheduled digest deduplication (one run per type per Pacific calendar day).

create table if not exists digest_runs (
  id uuid primary key default gen_random_uuid(),
  digest_type text not null check (digest_type in ('daily', 'weekly', 'monthly')),
  run_date date not null,
  created_at timestamptz not null default now(),
  unique (digest_type, run_date)
);

create index if not exists digest_runs_run_date_idx on digest_runs (run_date desc);

alter table digest_runs enable row level security;

-- Internal config for pg_cron → edge function auth (service role only).
create table if not exists app_config (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

alter table app_config enable row level security;

create extension if not exists pg_cron with schema pg_catalog;
create extension if not exists pg_net with schema extensions;

-- Hourly trigger: scheduled-digest runs only at 6 PM Pacific on the right days.
do $$
declare
  job_id bigint;
begin
  select jobid into job_id from cron.job where jobname = 'bb-finances-hourly-digest';
  if job_id is not null then
    perform cron.unschedule(job_id);
  end if;
end $$;

select cron.schedule(
  'bb-finances-hourly-digest',
  '0 * * * *',
  $$
  select net.http_post(
    url := coalesce(
      (select value from public.app_config where key = 'scheduled_digest_url'),
      ''
    ),
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-cron-secret', coalesce((select value from public.app_config where key = 'cron_secret'), '')
    ),
    body := '{}'::jsonb
  ) as request_id;
  $$
);
