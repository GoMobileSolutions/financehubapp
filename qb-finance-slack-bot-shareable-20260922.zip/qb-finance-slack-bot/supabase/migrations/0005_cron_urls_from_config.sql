-- Point cron jobs at THIS project's function URLs (stored in app_config).
-- Run via setup-schedules.sh after install; also applied for fresh projects.

-- Re-schedule digests to read URLs from app_config (no hardcoded project refs).
do $$
declare
  job_id bigint;
begin
  select jobid into job_id from cron.job where jobname = 'bb-finances-hourly-digest';
  if job_id is not null then
    perform cron.unschedule(job_id);
  end if;
  select jobid into job_id from cron.job where jobname = 'bb-finances-hourly-collections';
  if job_id is not null then
    perform cron.unschedule(job_id);
  end if;
end $$;

select cron.schedule(
  'bb-finances-hourly-digest',
  '0 * * * *',
  $$
  select net.http_post(
    url := coalesce((select value from public.app_config where key = 'scheduled_digest_url'), ''),
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-cron-secret', coalesce((select value from public.app_config where key = 'cron_secret'), '')
    ),
    body := '{}'::jsonb
  ) as request_id;
  $$
);

select cron.schedule(
  'bb-finances-hourly-collections',
  '0 * * * *',
  $$
  select net.http_post(
    url := coalesce((select value from public.app_config where key = 'collections_digest_url'), ''),
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-cron-secret', coalesce((select value from public.app_config where key = 'cron_secret'), '')
    ),
    body := '{}'::jsonb
  ) as request_id;
  $$
);
