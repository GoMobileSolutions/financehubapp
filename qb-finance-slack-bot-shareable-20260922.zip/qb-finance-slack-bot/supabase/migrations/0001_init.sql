-- QuickBooks <> Slack financial agent — initial schema
-- Two tables: OAuth token storage for QBO, and an audit log of every question asked.

create extension if not exists pgcrypto;

create table if not exists qb_connections (
  id uuid primary key default gen_random_uuid(),
  realm_id text not null unique,               -- QuickBooks Company ID
  environment text not null default 'production' check (environment in ('sandbox', 'production')),
  access_token text not null,
  access_token_expires_at timestamptz not null,
  refresh_token text not null,
  refresh_token_expires_at timestamptz not null,
  company_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Keep updated_at honest on every token refresh.
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists qb_connections_set_updated_at on qb_connections;
create trigger qb_connections_set_updated_at
  before update on qb_connections
  for each row execute function set_updated_at();

-- Audit trail: every Slack question, what QB calls the agent made, and the answer given.
-- This is your source of truth for "what is the team actually asking" — mine it before
-- deciding what to build next (new tools, cached reports, scheduled digests, etc).
create table if not exists query_log (
  id uuid primary key default gen_random_uuid(),
  slack_team_id text,
  slack_channel_id text,
  slack_user_id text,
  slack_thread_ts text,
  question text not null,
  qb_tool_calls jsonb not null default '[]'::jsonb,  -- [{tool, input, result_summary}, ...]
  answer text,
  error text,
  latency_ms integer,
  created_at timestamptz not null default now()
);

create index if not exists query_log_created_at_idx on query_log (created_at desc);
create index if not exists query_log_slack_user_idx on query_log (slack_user_id);

-- Lock these down: only the service role (used by the edge function) should touch them.
-- No anon/authenticated access — this table holds OAuth tokens.
alter table qb_connections enable row level security;
alter table query_log enable row level security;
-- No policies created = no access for anon/authenticated roles by default (service_role bypasses RLS).
